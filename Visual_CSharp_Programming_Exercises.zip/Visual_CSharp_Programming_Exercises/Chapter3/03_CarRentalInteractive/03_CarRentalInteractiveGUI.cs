﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter3
{
    public partial class CarRentalInteractiveGUI : Form
    {
        public CarRentalInteractiveGUI()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            int numOfDays;
            double numOfMiles;
            int pricePerDay = 20;
            double pricePerMiles = 0.25;
            double total;
            

            numOfDays = Convert.ToInt32(txtDays.Text);
            numOfMiles = Convert.ToDouble(txtMiles.Text);

            total = numOfDays * pricePerDay + numOfMiles * pricePerMiles;

            lblResult.Text = String.Format("The total price is: {0:C2}", total);
        }
    }
}
