﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter3
{
    public partial class ProjectedRaisesGUI : Form
    {
        public ProjectedRaisesGUI()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal inputSalary;
            decimal raise = 0.04M;
            decimal result;

            inputSalary = Convert.ToDecimal(txtInput.Text);

            result = inputSalary + inputSalary * raise;

            lblResult.Text = String.Format("Your salary is {0}.\nIt will be {1} with a 4% raise next year.", inputSalary, result);
        }

        private void txtInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblResult_Click(object sender, EventArgs e)
        {

        }
    }
}
