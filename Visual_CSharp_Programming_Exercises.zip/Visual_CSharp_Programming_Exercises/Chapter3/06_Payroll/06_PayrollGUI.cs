﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter3
{
    public partial class PayrollGUI : Form
    {
        public PayrollGUI()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string name,
                   ssn;
            decimal hourlyPay,
                    hoursWorked,
                    grossPay,
                    federalWithholding,
                    stateWithholding,
                    netPay;


            name = txtName.Text;
            ssn = txtSSN.Text;
            hourlyPay = Convert.ToDecimal(txtHourlyPay.Text);
            hoursWorked = Convert.ToDecimal(txtHoursWorked.Text);

            grossPay = hourlyPay * hoursWorked;
            federalWithholding = grossPay * 0.15M;
            stateWithholding = grossPay * 0.05M;
            netPay = grossPay - federalWithholding - stateWithholding;

            lblResult.Text = String.Format("Pay summary for {0}\n" +
                                           "Gross pay: {1, 30:C2}\n" +
                                           "Federal withholding tax: {2, 10:C2}\n" +
                                           "State withholding tax: {3, 14:C2}\n" +
                                           "Net Pay: {4, 33:C2}",
                                           name, grossPay, federalWithholding, stateWithholding, netPay);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
