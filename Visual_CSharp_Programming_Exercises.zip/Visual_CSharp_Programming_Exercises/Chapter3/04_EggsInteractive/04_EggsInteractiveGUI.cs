﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter3
{
    public partial class EggsInteractiveGUI : Form
    {
        public EggsInteractiveGUI()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int eggA,
                eggB,
                eggC,
                eggD,
                eggE,
                total,
                dozen,
                leftover;

            eggA = Convert.ToInt32(txtInput1.Text);
            eggB = Convert.ToInt32(txtInput2.Text);
            eggC = Convert.ToInt32(txtInput3.Text);
            eggD = Convert.ToInt32(txtInput4.Text);
            eggE = Convert.ToInt32(txtInput5.Text);

            total = eggA + eggB + eggC + eggD + eggE;
            dozen = total / 12;
            leftover = total % 12;

            lblResult.Text = String.Format("{0} egg{1} {2} dozen{3} with {4} leftover{5}.",
                                            total, total > 1 ? "s are" : " is", dozen, dozen > 1 ? "s" : "", leftover, leftover > 1 ? "s" : "");
        }
    }
}
