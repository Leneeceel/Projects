﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter3
{
    public partial class MilesToKilometresGUI : Form
    {
        public MilesToKilometresGUI()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_Cancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btn_Convert_Click(object sender, EventArgs e)
        {
            decimal input;
            decimal result;

            input = Convert.ToDecimal(txt_Input.Text);
            result = input / 1.8M;

            lbl_result.Text = String.Format("{0} miles are {1:F2} kilometres.", input, result);
        }
    }
}
