﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chapter3
{
    public partial class TestInteractiveGUI : Form
    {
        public TestInteractiveGUI()
        {
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double testScore1,
                   testScore2,
                   testScore3,
                   testScore4,
                   testScore5,
                   average;

            testScore1 = Convert.ToDouble(txtTest1.Text);
            testScore2 = Convert.ToDouble(txtTest2.Text);
            testScore3 = Convert.ToDouble(txtTest3.Text);
            testScore4 = Convert.ToDouble(txtTest4.Text);
            testScore5 = Convert.ToDouble(txtTest5.Text);

            average = (testScore1 + testScore2 + testScore3 + testScore4 + testScore5) / 5;

            lblResult.Text = String.Format("Your average is: {0:F2}", average);
        }
    }
}
