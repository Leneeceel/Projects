﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter6
{
    class ChatAWhile
    {
        static void Main(string[] args)
        {
            string[] areaCode;
            decimal[] perMinuteRate;
            string areaCodeInput;
            int callMinuteInput;
            int search;
            decimal totalCost;
            decimal costPerMinute;
            bool isItemFound;

            areaCode = new string[] { "262", "414", "608", "715", "815", "920" };
            perMinuteRate = new decimal[] { 0.07M, 0.10M, 0.05M, 0.16M, 0.24M, 0.14M };
            totalCost = 0;
            costPerMinute = 0;
            isItemFound = false;

            Write("Enter an area code: ");
            areaCodeInput = ReadLine();

            search = BinarySearch(areaCode, areaCodeInput);
            if (search < 0)
                isItemFound = false;
            else
                isItemFound = true;

            if (isItemFound)
            { 
                Write("Enter how many minutes you want to call for: ");
                callMinuteInput = Convert.ToInt32(ReadLine());

                totalCost = perMinuteRate[search] * callMinuteInput;
                costPerMinute = perMinuteRate[search];
            
                WriteLine("Area code: {0}\nRate per minute: {1}\nTotal cost: {2}", areaCodeInput, costPerMinute, totalCost);
            }
            else
                WriteLine("The area code was not found");
        }
    }
}
