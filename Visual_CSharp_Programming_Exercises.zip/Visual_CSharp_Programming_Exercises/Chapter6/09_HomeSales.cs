﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter6
{
    class HomeSales
    {
        static void Main(string[] args)
        {
            char initialInput;
            const char quit = 'Z';

            char[] initial = { 'D', 'E', 'F'};

            string[] salesPersonName = { "Danielle", "Edward", "Francis" };
            decimal[] eachPersonSales = { 0, 0, 0 };

            int search;

            decimal salesInput,
                    salesTotal = 0;
            
            Write("Enter a sales person initial (D, E, F): ");
            initialInput = Char.ToUpper(Convert.ToChar(ReadLine()));
            
            search = BinarySearch(initial, initialInput);

            while (initialInput != quit)
            {
                if (search >= 0)
                {
                    Write("Enter the amount of a sale: ");
                    salesInput = Convert.ToDecimal(ReadLine());

                    for (int i = 0; i < initial.Length; i++)
                    {
                        if (initialInput == initial[i])
                        {
                            eachPersonSales[i] += salesInput;
                        }
                    }
                }
                else
                    WriteLine("Invalid input.");

                Write("Enter a sales person initial, or Z to quit: ");
                initialInput = Char.ToUpper(Convert.ToChar(ReadLine()));

                search = BinarySearch(initial, initialInput);
            }

            for (int i = 0; i < eachPersonSales.Length; i++)
            {
                salesTotal += eachPersonSales[i];
            }
            
                WriteLine("**********Holyday Homes Sales data**********");
                for (int i = 0; i < salesPersonName.Length; i++)
                {
                    Write("{0, -30} {1, 13:C2}\n", salesPersonName[i], eachPersonSales[i]);
                }
                WriteLine("********************************************");
                WriteLine("Total: {0, 37:C}", salesTotal);
        }
    }
}
