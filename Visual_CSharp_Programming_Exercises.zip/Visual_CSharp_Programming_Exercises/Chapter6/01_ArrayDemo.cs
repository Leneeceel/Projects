﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter6
{
    class ArrayDemo
    {
        static void Main(string[] args)
        {
            int[] intArray = { 1, 2, 3, 4, 5, 6, 7, 8 };

            int userChoice,
                specifiedPosition;

            const int DASHES = 20;

            foreach (int item in intArray)
                Write("{0}  ", item);
            WriteLine();
            WriteLine("1) See the list in the order");
            WriteLine("2) See the list in the decending order");
            WriteLine("3) See a specific position");
            WriteLine("0) Quit");

            for (int i = 0; i < DASHES; i++)
                Write("-");
            WriteLine("\n\n");

            Write("Choose an option: ");
            userChoice = Convert.ToInt32(ReadLine());

           switch (userChoice)
            { 
                case 1:
                    for (int i = 0; i < intArray.Length; i++)
                        Write("{0}\t", intArray[i]);
                    WriteLine();
                    break;
                case 2:
                    for (int i = intArray.Length - 1; i >= 0; i--)
                        Write("{0}\t", intArray[i]);
                    WriteLine();
                    break;
                case 3:
                    Write("Enter a position (1~8): ");
                    specifiedPosition = Convert.ToInt32(ReadLine());
                    specifiedPosition = Array.BinarySearch(intArray, specifiedPosition);
                    WriteLine("The number at {0} position: {1}", specifiedPosition+1, intArray[specifiedPosition]);
                    break;
            }
        }
    }
}