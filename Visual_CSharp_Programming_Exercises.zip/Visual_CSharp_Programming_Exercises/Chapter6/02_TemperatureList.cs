﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter6
{
    class TemperatureList
    {
        static void Main(string[] args)
        {
            int[] intArray = new int[7];

            int average,
                highest;

            for (int i = 0; i < intArray.Length; i++)
            { 
                Write("Enter a number: ");
                intArray[i] = Convert.ToInt32(ReadLine());
            }
            
            WriteLine("\nNumbers are ");
            foreach(int num in intArray)
            {
                Write("{0}\t", num);
            }
            WriteLine();

            average = 0;
            for (int i = 0; i < intArray.Length; i++)
                average += intArray[i];
            average /= intArray.Length;
            
            WriteLine("\nThe average is: {0}", average);

            //The statement gives the maximum value of the array elements.
            //WriteLine("The highest number is: {0}", intArray.Max());

            //It can be done this way as well.
            Array.Sort(intArray);
            
            WriteLine("The highest number is: {0}", intArray[intArray.Length-1]);
        }
    }
}
