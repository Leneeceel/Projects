﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter6
{
    class ScoresComparison
    {
        static void Main(string[] args)
        {
            int[] scores = new int[4];

            int scoreInput;

            bool isScoreIncreasing = false,
                 isScoreDecreasing = false;

            string message;

            for (int i = 0; i < scores.Length; i++)
            {
                Write("Enter a score: ");
                scores[i] = Convert.ToInt32(ReadLine());
            }

            for (int i = 0; i < scores.Length; i++)
            { 
                if (i > 0)
                {
                    if (scores[i] > scores[i - 1])
                        isScoreIncreasing = true;
                    else if (scores[i] < scores[i - 1])
                        isScoreDecreasing = true;
                    else
                    {
                        isScoreIncreasing = false;
                        isScoreDecreasing = false;
                    }
                }
            }

            if (isScoreIncreasing)
                message = "An impressive improvement!";
            else if (isScoreDecreasing)
            { 
                message = "Try hard next time!";
            }
            else
                message = "Decent!";
            
            WriteLine("Your scores are");
            Sort(scores);
            foreach(int item in scores)
            {
                Write("  {0}  ", item);
            }
            WriteLine();

            WriteLine(message);

            if (isScoreDecreasing && !isScoreIncreasing)
            {
                Reverse(scores);
                foreach (int item in scores)
                {
                    Write("  {0}  ", item);
                }
                WriteLine();
            }
        }
    }
}
