﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter6
{
    class WhipperBus
    {
        static void Main(string[] args)
        {
            double[] ticketPrice = { 25, 40, 55, 70 };
            double[] distance = { 0, 100, 300, 500 };

            double distanceInput;
            double ticketPriceDisplayed = 0;

            Write("Enter a distance: ");
            distanceInput = Convert.ToDouble(ReadLine());

            //Both of the for loops do the same job
            for (int i = 0; i < ticketPrice.Length; i++)
            {
                if (distanceInput >= distance[i])
                    ticketPriceDisplayed = ticketPrice[i];
            }

            //for (int i = distance.Length-1; i >= 0; i--)
            //{
            //    if (distanceInput >= distance[i])
            //    { 
            //        ticketPriceDisplayed = ticketPrice[i];
            //        //flag
            //        i = -1;
            //    }
            //}

            WriteLine("The trip distance: {0}\nThe ticket price: {1}", distanceInput, ticketPriceDisplayed);
        }
    }
}
