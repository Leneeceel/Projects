﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter6
{
    class DeliveryCharges
    {
        static void Main(string[] args)
        {
            string[] zipCode;
            string zipCodeInput;
            decimal[] deliveryFee;
            int search;

            zipCode = new string[] { "A1A1A1", "A2A2A2", "A3A3A3", "A4A4A4", "A5A5A5", "A6A6A6", "A7A7A7", "A8A8A8", "A9A9A9", "A0A0A0" };
            deliveryFee = new decimal[] { 0M, 0M, 5M, 7M, 9M, 10M, 15M, 20M, 40M, 50M};
            

            Write("Enter a zipcode:");
            zipCodeInput = ReadLine();

            search = BinarySearch(zipCode, zipCodeInput);

            if (search < 0)
                WriteLine("The zipcode is not in the delivery area.");
            else
                WriteLine("The zip code: {0}.\nIt is in the delivery area.\nThe fee for the area is: {1:C2}", zipCodeInput, deliveryFee[search]);

        }
    }
}
