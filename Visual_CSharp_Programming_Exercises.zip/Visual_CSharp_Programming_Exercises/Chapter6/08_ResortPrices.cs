﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter6
{
    class ResortPrices
    {
        static void Main(string[] args)
        {
            int numOfDays;
            double price = 0;
            double total;

            double[] priceRange = { 200, 180, 160, 145 };
            int[] dayRange = { 1, 3, 5, 8 };

            Write("Enter how many days you want: ");
            numOfDays = Convert.ToInt32(ReadLine());

            for (int i = 0; i < dayRange.Length; i++)
            {
                if (numOfDays >= dayRange[i])
                {
                    price = priceRange[i];
                }
            }

            //for (int i = dayRange.Length - 1; i >= 0; i--)
            //{
            //    if (numOfDays >= dayRange[i])
            //    { 
            //        price = priceRange[i];
            //        i = -1;
            //    }
            //}

            total = price * numOfDays;

            WriteLine("{0} day{1}\n{2:C} per day\nTotal: {3:C}", numOfDays, numOfDays>1?"s":"", price, total);
        }
    }
}
