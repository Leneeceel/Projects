﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter6
{
    class GuessAWord
    {
        static void Main(string[] args)
        {
            string[] words = { "water", "jackass", "rum", "vodka",
                               "starcraft", "game", "program", "excel" };
            string randomWord;
            char[] randomWordHidden = new char[10];
            string aLetterInput;
            bool isGameComplete = false;
            bool isRightLetter = false;
            int randomNum;
            int letterCount = 0;
            Random randomWordGenerator = new Random();

            randomNum = randomWordGenerator.Next(0, words.Length-1);

            randomWord = words[randomNum];

            for (int i = 0; i < randomWord.Length; i++)
                randomWordHidden[i] = '*';

            while (!isGameComplete)
            {
                WriteLine(randomWordHidden);
                Write("Guess a letter >> ");
                aLetterInput = ReadLine();

                for (int i = 0; i < randomWord.Length; i++)
                {
                    if (Equals(aLetterInput, randomWord.Substring(i, 1)))
                    {
                        isRightLetter = true;
                        randomWordHidden[i] = Char.ToLower(Convert.ToChar(aLetterInput));

                        letterCount++;
                    }
                }

                if (isRightLetter)
                    WriteLine("Yes! {0} is in the word!\n", aLetterInput);
                else
                    WriteLine("Sorry, {0} is not in the word.\n", aLetterInput);

                isRightLetter = false;

                if (letterCount == randomWord.Length)
                    isGameComplete = true;
                
            }

            WriteLine("The letter is {0}!", randomWord);
            WriteLine("You have completed the game!\nCongratulations!\n");
        }
    }
}