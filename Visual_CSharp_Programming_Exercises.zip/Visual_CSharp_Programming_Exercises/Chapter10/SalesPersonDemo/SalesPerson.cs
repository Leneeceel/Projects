﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesPersonDemo
{
    abstract class SalesPerson
    {
        public string FName { get; set; }
        public string LName { get; set; }
        public SalesPerson(string fname, string lname)
        {
            FName = fname;
            LName = lname;
        }
        public string FullName()
        {
            return string.Format($"{FName} {LName}");
        }
    }
}
