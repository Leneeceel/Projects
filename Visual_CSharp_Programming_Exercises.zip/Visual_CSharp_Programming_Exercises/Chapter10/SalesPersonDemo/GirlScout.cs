﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesPersonDemo
{
    class GirlScout : SalesPerson, ISellable
    {
        int cookieBoxesSold = 0;
        public int CookieBoxesSold
        {
            get { return cookieBoxesSold; }
        }

        public void MakeSale(int numOfBoxes)
        {
            cookieBoxesSold += numOfBoxes;
            Console.WriteLine($"Sale made: {numOfBoxes}\n" +
                                    $"Total: {CookieBoxesSold}");
        }

        public string SalesSpeech()
        {
            return String.Format($"I am {FullName()}\nBuy a box of cookies!");
        }
        public GirlScout(string fName, string lName) : base(fName, lName)
        {
           
        }
    }
}
