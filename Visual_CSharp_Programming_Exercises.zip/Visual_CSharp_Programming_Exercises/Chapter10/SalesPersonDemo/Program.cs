﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesPersonDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            RealEstateSalesperson resp1 = new RealEstateSalesperson("a", "b", 0.02);
            Console.WriteLine(resp1.SalesSpeech());
            resp1.MakeSale(20000);
            GirlScout gs1 = new GirlScout("c", "d");
            Console.WriteLine(gs1.SalesSpeech());
            gs1.MakeSale(2);
            gs1.MakeSale(3);
        }
    }
}