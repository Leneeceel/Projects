﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesPersonDemo
{
    class RealEstateSalesperson : SalesPerson, ISellable
    {
        double totalValueSold = 0;
        double commisionRate;
        public double TotalValueSold { get; set; }
        public double TotalCommisionEarned { get; set; }
        public double CommisionRate { get; set; }
        public RealEstateSalesperson(string fName, string lName, double commisionRate) : base(fName, lName)
        {
            this.commisionRate = commisionRate;
        }

        public string SalesSpeech()
        {
            return String.Format($"I am {FullName()}\nBuy something!");
        }

        public void MakeSale(int dollar)
        {
            totalValueSold += dollar;
            TotalCommisionEarned += totalValueSold;
            Console.WriteLine($"Sale made: {dollar}");
        }
    }
}
