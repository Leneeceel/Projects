﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TurningDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Page p1 = new Page();
            Console.WriteLine(p1.Turn());
            Corner c1 = new Corner();
            Console.WriteLine(c1.Turn());
            Pancake p2 = new Pancake();
            Console.WriteLine(p2.Turn());
            Leaf l1 = new Leaf();
            Console.WriteLine(l1.Turn());
        }
    }
}
