﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TurningDemo
{
    class Leaf : ITurnable
    {
        public string Turn()
        {
            return String.Format("turn a leaf");
        }

    }
}
