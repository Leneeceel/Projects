﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesDemo
{
    class Square : Rectangle
    {
        public Square(int height, int width)
        {
            if (height != width)
                Console.WriteLine("Height and width are not equal; it is not a square.");
            else
            { 
                Height = height;
                Width = width;
            }
        }

        public Square(int length)
        {
            Height = length;
            Width = length;
            ComputeArea();
        }
        
    }
}
