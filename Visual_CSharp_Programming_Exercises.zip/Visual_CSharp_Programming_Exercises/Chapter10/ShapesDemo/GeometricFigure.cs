﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesDemo
{
    abstract class GeometricFigure
    {
        protected int height,
                      width,
                      area;

        public int Height
        {
            get { return height; }
            set
            {
                height = value;
                ComputeArea();
            }
        }
        public int Width
        {
            get { return width; }
            set
            {
                width = value;
                ComputeArea();
            }
        }
        public int Area
        {
            get { return area; }
        }
        public abstract void ComputeArea();
    }
}
