﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesDemo
{
    class Tryangle : GeometricFigure
    {
        public override void ComputeArea()
        {
            area = Width * (Height/2);
        }
    }
}