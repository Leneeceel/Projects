﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesDemo
{
    static class Program
    {
        static void Main(string[] args)
        {
            Rectangle r1 = new Rectangle() { Height = 2, Width = 5 };
            Display(r1);
            Square s1 = new Square(2, 5);
            Square s2 = new Square(2);
            Display(s1);
            Display(s2);
            Tryangle t1 = new Tryangle() { Height = 4, Width = 5 };
            Display(t1);
            t1.Height = 6;
            t1.Width = 3;
            Display(t1);
        }
        public static void Display(GeometricFigure g1)
        {
            Console.WriteLine($"Type: {g1.GetType()}\nHeight: {g1.Height}\nWidth: {g1.Width}" +
                                $"\nArea: {g1.Area}\n");
        }
    }
}
