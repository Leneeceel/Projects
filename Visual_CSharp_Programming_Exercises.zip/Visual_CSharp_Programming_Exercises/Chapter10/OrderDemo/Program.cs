﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderDemo3
{
    class Program
    {
        static void Main(string[] args)
        {
            Order order1 = new Order(1, "order1", 1);
            Order order2 = new Order(2, "order2", 2);
            Console.WriteLine(order1);
            Console.WriteLine(order2);

            Order order3 = new Order(1, "order3", 3);
            Console.WriteLine(order3);
            order1.Equal(order2);
            order1.Equal(order3);
        }
    }
}