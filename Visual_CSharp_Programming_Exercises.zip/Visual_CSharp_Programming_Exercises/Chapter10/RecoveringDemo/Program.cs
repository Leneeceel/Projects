﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecoveringDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Patient p1 = new Patient();
            Console.WriteLine(p1.Recover()+"\n");
            FootballPlayer f1 = new FootballPlayer();
            Console.WriteLine(f1.Recover()+"\n");
            Upholsterer u1 = new Upholsterer();
            Console.WriteLine(u1.Recover());
        }
    }
}
