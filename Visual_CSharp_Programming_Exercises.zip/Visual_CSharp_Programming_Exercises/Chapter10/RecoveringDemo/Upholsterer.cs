﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecoveringDemo
{
    class Upholsterer : IRecoverable
    {
        public string Recover()
        {
            return String.Format("I am a Upholsterer.\nI am getting better.");
        }

    }
}
