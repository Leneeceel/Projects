﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RecoveringDemo
{
    class FootballPlayer : IRecoverable
    {
        public string Recover()
        {
            return String.Format("I am a foot ball player.\nI am getting better.");
        }
    }
}
