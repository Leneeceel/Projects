﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LetterDemo
{
    class Letter
    {
        public string Name { get; set; }
        public string MailedDate { get; set; }

        public override string ToString()
        {
            return String.Format($"{GetType()} \n{Name}\n{MailedDate}");
        }
    }
}
