﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LetterDemo
{
    class CertifiedLetter : Letter
    {
        public int TrackingNum { get; set; }
        public override string ToString()
        {
            string result = base.ToString();
            return result += String.Format($"\n{TrackingNum}");
        }
    }
}
