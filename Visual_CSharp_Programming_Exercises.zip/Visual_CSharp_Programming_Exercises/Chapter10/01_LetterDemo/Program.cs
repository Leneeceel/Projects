﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LetterDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Letter aLetter = new Letter(){ Name = "A name", MailedDate = "1992 02 02" };

            Console.WriteLine(aLetter);

            CertifiedLetter aCerLetter = new CertifiedLetter()
                { Name = "A name", MailedDate = "1992 02 02", TrackingNum = 5};
            Console.WriteLine(aCerLetter);
        }
    }
}
