﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace AutomobileDemo2
{
    class Program
    {
        static void Main(string[] args)
        {
            FinancedAutomobile[] automobiles = new FinancedAutomobile[4];
            for (int i = 0; i < automobiles.Length; i++)
            {
                WriteLine($"Automobile #{i + 1}");
                automobiles[i] = new FinancedAutomobile();
                Write("Enter ID: ");
                automobiles[i].ID = ReadLine();
                foreach (FinancedAutomobile a in automobiles)
                {
                    if (a != null)
                    {
                        while (automobiles[i].ID == a.ID && automobiles[i] != a)
                        {
                            Write("ID already exists.\nEnter ID: ");
                            automobiles[i].ID = ReadLine();
                        }
                    }
                }

                Write("Enter price: ");
                automobiles[i].Price = Convert.ToInt32(ReadLine());
                Write("Enter make: ");
                automobiles[i].Make = ReadLine();
                Write("Enter year: ");
                automobiles[i].Year = Convert.ToInt32(ReadLine());
                Write("Enter financed amount: ");
                automobiles[i].AmountFinanced = Convert.ToDouble(ReadLine());
                Write("Enter interest rate: ");
                automobiles[i].InterestRate = Convert.ToDouble(ReadLine());
                WriteLine("\n");
            }

            FinancedAutomobile total = new FinancedAutomobile();
            foreach (FinancedAutomobile a in automobiles)
            {
                total += a;
                WriteLine(a);
                WriteLine();
            }

            WriteLine($"Total: {total.Price}");
        }
    }
}
