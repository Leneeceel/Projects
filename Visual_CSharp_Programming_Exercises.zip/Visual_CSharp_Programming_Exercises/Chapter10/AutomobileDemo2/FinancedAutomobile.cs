﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomobileDemo2
{
    class FinancedAutomobile : Automobile
    {
        double amountFinanced;
        double interestRate;

        public double AmountFinanced
        {
            get {return amountFinanced; }
            set
            {
                amountFinanced = value;
                while (amountFinanced > Price)
                {
                    Console.WriteLine("Financed amount cannot be greater than price.");
                    Console.Write("Enter Financed amount: ");
                    this.amountFinanced = Convert.ToDouble(Console.ReadLine());
                }
            }
        }
        public double InterestRate
        {
            get { return interestRate; }
            set { interestRate = value; }
        }


        public override string ToString()
        {
            return base.ToString() + $"\nAmount Financed: {amountFinanced}\nInterest Rate: {InterestRate:P2}";
        }
        public static FinancedAutomobile operator +(FinancedAutomobile a1, FinancedAutomobile a2)
        {
            FinancedAutomobile totalPrice = new FinancedAutomobile();
            totalPrice.Price = a1.Price + a2.Price;
            return totalPrice;
        }

    }
}
