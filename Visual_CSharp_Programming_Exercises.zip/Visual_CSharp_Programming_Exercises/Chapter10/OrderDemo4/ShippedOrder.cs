﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderDemo4
{
    class ShippedOrder : Order, IComparable
    {
        //public ShippedOrder() : base()
        //{
        //    PRICE += 4;
        //}
        public new int Quantity
        {
            get { return quantity; }
            set
            {
                quantity = value;
                total = PRICE * quantity + 4;
            }
        }

        //public int CompareTo(object obj)
        //{
        //    ShippedOrder so = (ShippedOrder)obj;

        //    return String.Compare(Convert.ToString(this.GetHashCode()), Convert.ToString(so.GetHashCode()));
        //}
        public int CompareTo(object obj)
        {
            int returnVal;
            ShippedOrder so = (ShippedOrder)obj;
            if (this.GetHashCode() > so.GetHashCode())
                returnVal = 1;
            else if (this.GetHashCode() < so.GetHashCode())
                returnVal = -1;
            else
                returnVal = 0;
            return returnVal;
        }

        public static ShippedOrder operator+(ShippedOrder so1, ShippedOrder so2)
        {
            ShippedOrder totalPrice = new ShippedOrder();
            totalPrice.total = so1.Total + so2.Total;
            return totalPrice;
        }
    }
}
