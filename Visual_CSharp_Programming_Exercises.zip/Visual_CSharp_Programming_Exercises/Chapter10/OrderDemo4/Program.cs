﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderDemo4
{
    class Program
    {
        static void Main(string[] args)
        {
            //ShippedOrder[] shippedOrders = new ShippedOrder[2];
            //shippedOrders[0] = new ShippedOrder() { OrderNo = 2, Name = "B", Quantity = 2 };
            //shippedOrders[1] = new ShippedOrder() { OrderNo = 1, Name = "A", Quantity = 1 };
            //foreach (Order o in shippedOrders)
            //{
            //    Console.WriteLine(o+"\n");
            //}
            //Console.WriteLine("After sorting\n");
            //Array.Sort<ShippedOrder>(shippedOrders);

            //foreach (Order o in shippedOrders)
            //{
            //    Console.WriteLine(o+"\n");
            //}
            ShippedOrder[] orders = new ShippedOrder[5];

            Console.WriteLine("Enter five orders");

            for (int i = 0; i < orders.Length; i++)
            {
                orders[i] = new ShippedOrder();
                Console.Write("Enter order#: ");
                orders[i].OrderNo = Convert.ToInt16(Console.ReadLine());
                foreach (Order o in orders)
                {
                    if (o != null)
                    {
                        while (orders[i].OrderNo == o.OrderNo && orders[i] != o)
                        {
                            Console.WriteLine("Order# exists.\nEnter another order#: ");
                            orders[i].OrderNo = Convert.ToInt16(Console.ReadLine());
                        }
                    }
                }
                Console.Write("Enter name: ");
                orders[i].Name = Console.ReadLine();
                Console.Write("Enter quantity: ");
                orders[i].Quantity = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("\n\n");
            }

            ShippedOrder totalPrice = new ShippedOrder();
            Console.WriteLine("All orders");
            foreach (ShippedOrder o in orders)
            {
                totalPrice += o;
                Console.WriteLine($"{o}\n");
            }
            Console.WriteLine($"Total price: {totalPrice.Total}");


        }
    }
}
