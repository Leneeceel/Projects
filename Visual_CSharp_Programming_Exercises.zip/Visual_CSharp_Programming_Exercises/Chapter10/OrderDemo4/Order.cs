﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderDemo4
{
    class Order
    {
        int orderNo;
        string name;
        protected int quantity;
        protected double total;
        protected double PRICE = 19.95;
        public int OrderNo
        {
            get { return orderNo; }
            set { orderNo = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Quantity
        {
            get { return quantity; }
            set
            {
                quantity = value;
                total = PRICE * quantity;
            }
        }
        public double Total
        {
            get { return total; }
        }
        public Order(int orderNo, string name, int quantity)
        {
            OrderNo = orderNo;
            Name = name;
            Quantity = quantity;
        }
        public Order()
        {

        }
        public override bool Equals(object obj)
        {
            Order o1 = (Order)obj;
            bool isEqual;
            if (OrderNo == o1.OrderNo)
                isEqual = true;
            else
                isEqual = false;

            return isEqual;
        }
        public override int GetHashCode()
        {
            return OrderNo;
        }
        public override string ToString()
        {
            return String.Format($"Order Number: {OrderNo}\nCustomer Name: {Name}" +
                                    $"\nQuantity: {Quantity}\nTotal Price: {Total}");
        }

        public void Equal(object o1)
        {
            Order order1 = (Order)o1;
            if (Equals(o1))
                Console.WriteLine($"Two orders are the same");
            else
                Console.WriteLine($"Two orders are not the same");
        }
    }
}
