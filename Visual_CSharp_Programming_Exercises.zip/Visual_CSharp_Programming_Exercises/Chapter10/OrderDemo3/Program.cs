﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderDemo3
{
    class Program
    {
        static void Main(string[] args)
        {
            //ShippedOrder a = new ShippedOrder();
            //a.OrderNo = 1;
            //a.Name = "a";
            //a.Quantity = 1;
            //Console.WriteLine(a);
            ShippedOrder[] orders = new ShippedOrder[5];
            double total = 0;

            Console.WriteLine("Enter five orders");

            for (int i = 0; i < orders.Length; i++)
            {
                orders[i] = new ShippedOrder();
                Console.Write("Enter order#: ");
                orders[i].OrderNo = Convert.ToInt16(Console.ReadLine());
                foreach (Order o in orders)
                {
                    if (o != null)
                    {
                        while (orders[i].OrderNo == o.OrderNo && orders[i] != o)
                        {
                            Console.WriteLine("Order# exists.\nEnter another order#: ");
                            orders[i].OrderNo = Convert.ToInt16(Console.ReadLine());
                        }
                    }
                }
                Console.Write("Enter name: ");
                orders[i].Name = Console.ReadLine();
                Console.Write("Enter quantity: ");
                orders[i].Quantity = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("\n\n");
                total += orders[i].Total;
            }

            foreach (Order o in orders)
            {
                Console.WriteLine($"{o}\n");
            }
            Console.WriteLine($"Total: {total}");
        }
    }
}
