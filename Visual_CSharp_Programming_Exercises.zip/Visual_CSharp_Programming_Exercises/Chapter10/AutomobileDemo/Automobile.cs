﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutomobileDemo
{
    class Automobile : IComparable
    {
        public string ID { get; set; }
        public int Year { get; set; }
        public string Make { get; set; }
        public double Price { get; set; }

        public int CompareTo(object obj)
        {
            Automobile a1 = (Automobile)obj;
            return String.Compare(this.ID, a1.ID);
        }

        public override string ToString()
        {
            return $"ID: {ID}\nYear: {Year}\nMake: {Make}\nPrice: {Price}";
        }

        public static Automobile operator+(Automobile a1, Automobile a2)
        {
            Automobile totalPrice = new Automobile();
            totalPrice.Price = a1.Price + a2.Price;
            return totalPrice;
        }
    }
}
