﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoDemo
{
    class Photo
    {
        int width;
        int height;
        protected double price;
        public int Width
        {
            get { return width; }
            set
            {
                width = value;
                SetPrice();
            }
        }
        public int Height
        {
            get { return height; }
            set
            {
                height = value;
                SetPrice();
            }
        }
        public double Price
        {
            get { return price; }
        }
        public Photo()
        {

        }

        public virtual void SetPrice()
        {
            if (Width == 8 && Height == 10)
                price += 3.99;
            else if (Width == 10 && Height == 12)
                price += 5.99;
            else
                price += 9.99;
        }

        public override string ToString()
        {
            return String.Format($"{GetType()}\nWidth: {Width}\nHeight: {Height}\nPrice: {Price}");
        }

    }
}
