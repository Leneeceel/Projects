﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Photo aPhoto = new Photo() { Width = 8, Height = 10 };
            Console.WriteLine(aPhoto);
            //MattedPhoto bPhoto = new MattedPhoto() { Width = 8, Height = 10 };
            MattedPhoto bPhoto = new MattedPhoto();
            bPhoto.Width = 8;
            bPhoto.Height = 10;
            Console.WriteLine(bPhoto);
            FramedPhoto cPhoto = new FramedPhoto() { Width = 8, Height = 10 };
            Console.WriteLine(cPhoto);
        }
    }
}
