﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoDemo
{
    class MattedPhoto : Photo
    {
        string colour = "red";
        //public override double Price
        //{
        //    get
        //    {
        //        price += 10;
        //        return price;
        //    }
        //}
        public MattedPhoto() : base()
        {
            price += 10;
        }
        //public override void SetPrice()
        //{
        //    base.SetPrice();
        //    price += 10;
        //}

        public override string ToString()
        {
            string result = base.ToString();
            return result += String.Format($"\nColour: {colour}");
        }
    }
}
