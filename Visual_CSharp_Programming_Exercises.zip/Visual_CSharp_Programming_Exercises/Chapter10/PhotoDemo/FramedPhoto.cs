﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhotoDemo
{
    class FramedPhoto : Photo
    {
        string material = "gold";
        string style = "antique";
        //public override void SetPrice()
        //{
        //    base.SetPrice();
        //    price += 25;
        //}
        public FramedPhoto() : base()
        {
            price += 25;
        }
        public override string ToString()
        {
            string result = base.ToString();
            return result += String.Format($"\nMaterial: {material} \nStyle: {style}");
        }

    }
}
