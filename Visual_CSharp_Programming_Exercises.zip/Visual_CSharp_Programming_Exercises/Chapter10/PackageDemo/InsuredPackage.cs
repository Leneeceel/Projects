﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageDemo
{
    class InsuredPackage : Package
    {
        double value;
        protected override void SetPrice()
        {
            base.SetPrice();
            value = 1;
            if (deliveryPrice >= 20)
                value = 2.5;
            deliveryPrice += value;
        }
    }
}
