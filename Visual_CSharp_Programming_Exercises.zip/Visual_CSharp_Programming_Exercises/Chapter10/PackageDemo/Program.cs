﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Package p1 = new Package() { ID = 1, Name = "A", Weight = 32 };
            Package p2 = new Package() { ID = 2, Name = "B", Weight = 33 };
            Console.WriteLine(p1);
            Console.WriteLine(p2);
            InsuredPackage p3 = new InsuredPackage() { ID = 3, Name = "C", Weight = 200 };
            Console.WriteLine(p3);
        }
    }
}
