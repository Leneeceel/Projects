﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PackageDemo
{
    class Package
    {
        protected double deliveryPrice;
        int weight;
        public int ID { get; set; }
        public string Name { get; set; }
        public int Weight
        {
            get { return weight; }
            set
            {
                weight = value;
                SetPrice();
            }
        }
        protected virtual void SetPrice()
        {
            deliveryPrice = 5;
            if (Weight > 32)
                deliveryPrice += (Weight - 32) * .12;
        }

        public override string ToString()
        {
            return $"ID: {ID} \nPrice: {deliveryPrice}\n";
        }
    }
}
