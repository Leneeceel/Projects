﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class TestScores
    {
        static void Main(string[] args)
        {
            double totalScore = 0,
                   scoreAdded = 0;
            int    numOfScores = 0;
            string inputString;
            
            Write("Enter a score: ");
            scoreAdded = Convert.ToDouble(ReadLine());

            while(scoreAdded != 0)
            {
                totalScore += scoreAdded;
                Write("Enter a score, or 0 to quit: ");
                scoreAdded = Convert.ToInt32(ReadLine());
                numOfScores++;
            }

            WriteLine("The number of score: {0}.\nThe average score is: {1:F2}.", numOfScores, totalScore / numOfScores);
        }
    }
}
