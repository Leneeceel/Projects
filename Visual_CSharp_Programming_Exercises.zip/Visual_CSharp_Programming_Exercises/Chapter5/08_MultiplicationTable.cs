﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class MultiplicationTable
    {
        static void Main(string[] args)
        {
            int input;

            Write("Enter an integer: ");
            input = Convert.ToInt32(ReadLine());

            for (int i = 1; i <= 10; i++)
                WriteLine(input * i);
        }
    }
}
