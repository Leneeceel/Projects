﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class WebAddress
    {
        static void Main(string[] args)
        {
            string stringInput,
                   webAddress = "";

            Write("Enter a web page address: ");
            stringInput = ReadLine();

            for (int i = 0; i < stringInput.Length; i++)
            {
                if (stringInput.Substring(i, 1) != " ")
                    webAddress += stringInput.Substring(i, 1);
            }

            WriteLine("Your web address is: {0}", "www." + webAddress + ".com");
        }
    }
}
