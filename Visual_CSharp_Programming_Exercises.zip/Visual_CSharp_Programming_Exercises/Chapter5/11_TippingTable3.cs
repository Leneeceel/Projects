﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class TippingTable
    {
        static void Main(string[] args)
        {
            double dinnerPrice,
                   maxDinner,
                   tipRate,
                   tip,
                   lowRate,
                   maxRate;

            const double TIPSTEP = 0.05,
                         DINNERSTEP = 10.00;

            const int NUM_DASHES = 40;

            Write("Enter the lowest tipping percentage: ");
            lowRate = Convert.ToDouble(ReadLine());
            Write("Enter the highest tipping percentage: ");
            maxRate = Convert.ToDouble(ReadLine());
            Write("Enter the lowest restaurant bill: ");
            dinnerPrice = Convert.ToDouble(ReadLine());
            Write("Enter the highest restaurant bill: ");
            maxDinner = Convert.ToDouble(ReadLine());

            Write("   Price");
            for (tipRate = lowRate; tipRate <= maxRate; tipRate += TIPSTEP)
                Write("{0, 8}", tipRate.ToString("F"));
            WriteLine();
            for (int i = 0; i < NUM_DASHES; i++)
                Write("-");
            WriteLine();

            tipRate = lowRate;

            do
            {
                Write("{0, 8}", dinnerPrice.ToString("C"));
                while (tipRate <= maxRate)
                {
                    tip = dinnerPrice * tipRate;
                    Write("{0, 8}", tip.ToString("C"));
                    tipRate += TIPSTEP;
                }
                dinnerPrice += DINNERSTEP;
                tipRate = lowRate;
                WriteLine();
            }
            while (dinnerPrice <= maxDinner);


        }
    }
}
