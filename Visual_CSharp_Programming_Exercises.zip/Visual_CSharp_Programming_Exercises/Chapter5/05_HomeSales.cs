﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class HomeSales
    {
        static void Main(string[] args)
        {
            char input = ' ',
                 quit = 'Z';

            decimal sales,
                    salesDanielle = 0,
                    salesEdward = 0,
                    salesFrancis = 0,
                    salesTotal = 0;

            Write("Enter a salesperson initial (D, E, F): ");
            input = Char.ToUpper(Convert.ToChar(ReadLine()));

            while ( input != quit )
            {

                if (input == 'D' || input == 'E' || input == 'F')
                {
                    Write("Enter the aount of a sales: ");
                    sales = Convert.ToDecimal(ReadLine());

                    switch (input)
                    {
                        case 'D':
                            salesDanielle += sales;
                            break;
                        case 'E':
                            salesEdward += sales;
                            break;
                        case 'F':
                            salesFrancis += sales;
                            break;
                        default:
                            break;
                    }
                }
                else
                    WriteLine("Invalid input");

                Write("Enter a sales person initial, or Z to quit: ");
                input = Char.ToUpper(Convert.ToChar(ReadLine()));
            }

            salesTotal = salesDanielle + salesEdward + salesFrancis;
                WriteLine("**********Holyday Homes Sales data**********");
                WriteLine("Danielle: {0, 30:C2}\n" +
                          "Edward:   {1, 30:C2}\n" +
                          "Francis:  {2, 30:C2}", salesDanielle, salesEdward, salesFrancis);
                WriteLine("********************************************");
                WriteLine("Total:    {0, 30:C2}", salesTotal);
        }
    }
}