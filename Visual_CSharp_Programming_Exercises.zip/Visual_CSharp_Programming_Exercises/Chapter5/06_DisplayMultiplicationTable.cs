﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class DisplayMultiplicationTable
    {
        static void Main(string[] args)
        {
            for (int i = 1; i < 10; i++)
            {
                int ii = i+1;

                WriteLine("{0}", i + ii);
            }
        }
    }
}
