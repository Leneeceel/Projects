﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class EnterLowercaseLetters
    {
        static void Main(string[] args)
        {
            char input = ' ';
            
            while (!char.IsLower(input))
            {
                Write("Enter a lower case letter: ");
                input = Convert.ToChar(ReadLine());
            }

            WriteLine("The letter is lower case.");

        }
    }
}
