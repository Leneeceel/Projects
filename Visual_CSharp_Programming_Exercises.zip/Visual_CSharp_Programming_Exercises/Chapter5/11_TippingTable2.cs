﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class TippingTable
    {
        static void Main(string[] args)
        {
            double dinnerPrice = 10.00,
                   tipRate,
                   tip;

            const double LOWRATE = 0.10,
                         MAXRATE = 0.25,
                         TIPSTEP = 0.05,
                         MAXDINNER = 100.00,
                         DINNERSTEP = 10.00;

            const int NUM_DASHES = 40;

            Write("   Price");
            for (tipRate = LOWRATE; tipRate <= MAXRATE; tipRate += TIPSTEP)
                Write("{0, 8}", tipRate.ToString("F"));
            WriteLine();
            for (int i = 0; i < NUM_DASHES; i++)
                Write("-");
            WriteLine();

            tipRate = LOWRATE;

            do
            {
                Write("{0, 8}", dinnerPrice.ToString("C"));
                while (tipRate <= MAXRATE)
                {
                    tip = dinnerPrice * tipRate;
                    Write("{0, 8}", tip.ToString("C"));
                    tipRate += TIPSTEP;
                }
                dinnerPrice += DINNERSTEP;
                tipRate = LOWRATE;
                WriteLine();
            }
            while (dinnerPrice <= MAXDINNER);


        }
    }
}
