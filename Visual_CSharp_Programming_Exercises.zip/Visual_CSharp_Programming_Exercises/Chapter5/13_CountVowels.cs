﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class CountVowels
    {
        static void Main(string[] args)
        {
            string input;

            int numOfVowels = 0;

            Write("Say something!\n");
            input = ReadLine();

            for (int i = 0; i < input.Length; i++)
            {
                if (input.Substring(i, 1) == "a" ||
                    input.Substring(i, 1) == "e" ||
                    input.Substring(i, 1) == "i" ||
                    input.Substring(i, 1) == "o" ||
                    input.Substring(i, 1) == "u")
                    numOfVowels++;
            }

            WriteLine("There {0} {1} vowel{2} in it!", numOfVowels > 1 ? "are" : "is",
                                                       numOfVowels,
                                                       numOfVowels > 1 ? "s" : "");
        }
    }
}
