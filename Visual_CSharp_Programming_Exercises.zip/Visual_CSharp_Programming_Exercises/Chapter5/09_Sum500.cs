﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class Sum500
    {
        static void Main(string[] args)
        {
            int result = 0;

            for (int i = 0; i <= 500; i++)
            {
                result += i;
            }

            WriteLine(result);
        }
    }
}
