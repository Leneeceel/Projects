﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter4
{
    class GuessingGame
    {
        static void Main(string[] args)
        {
            Random randomGenerator = new Random();
            int randomNumber,
                roundCount = 0,
                min = 1,
                max = 11,
                ranNumInput;

            randomNumber = randomGenerator.Next(min, max);
            
            Write("Guess a random number (1~10): ");
            ranNumInput = Convert.ToInt32(ReadLine());
            roundCount++;
            
            while (ranNumInput != randomNumber)
            {
                Write("Try again!: ");
                ranNumInput = Convert.ToInt32(ReadLine());
                roundCount++;
            }

            WriteLine("You have won!\n" +
                      "You have tried {0} time{1}", roundCount, roundCount > 1 ? "s":"");
        }
    }
}
