﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class Perfect
    {
        static void Main(string[] args)
        {
            double num,
                   sum;

            for (double i = 1; i <= 1000; i++)
            {
                num = 1;
                sum = 0;

                while(num<i)
                {
                    if (i % num == 0)
                        sum += num;
                    num++;
                }

                if (sum == i)
                    WriteLine(i);
            }
        }
    }
}
