﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class SumInts
    {
        static void Main(string[] args)
        {
            int num = 0,
                addedNum;

            for (int i = 0; num < 999; i++)
            {
                Write("Pick a number to add: ");
                addedNum = Convert.ToInt32(ReadLine());

                if (addedNum < 999)
                    num += addedNum;
            }
            
            WriteLine("The number added is: {0}", num);
        }
    }
}