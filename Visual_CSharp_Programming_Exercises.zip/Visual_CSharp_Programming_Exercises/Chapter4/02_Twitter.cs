﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter4
{
    class Twitter
    {
        static void Main(string[] args)
        {
            string message;

            Write("Write a message:\n");
            message = ReadLine();

            if (message.Length < 140)
                WriteLine("The message is acceptable.");
            else
                WriteLine("The message is longer than 140 characters.");
        }
    }
}
