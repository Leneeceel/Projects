﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter4
{
    class RockPaperScissors
    {
        static void Main(string[] args)
        {
            Random rspGenerator = new Random();
            int randomNum,
                userNum,
                rock = 0,
                scissor = 1,
                paper = 2;

            randomNum = rspGenerator.Next(rock, paper+1);

            string computerPick,
                   userPick;

            switch(randomNum)
            {
                case 0:
                    computerPick = "rock";
                    break;
                case 1:
                    computerPick = "scissors";
                    break;
                case 2:
                    computerPick = "paper";
                    break;
                default:
                    computerPick = "";
                    break;
            }
            
            char input;

            Write("Choose rock, scissor, or paper (r for rock, s for scissors, and p for paper): ");
            input = Convert.ToChar(ReadLine());

            if (input == 'r')
            { 
                userNum = 0;
                userPick = "rock";
            }
            else if (input == 's')
            { 
                userNum = 1;
                userPick = "scissors";
            }
            else if (input == 'p')
            { 
                userNum = 2;
                userPick = "paper";
            }
            else
            {
                userNum = 4;
                userPick = "";
                WriteLine("Invalid input");
            }

            if (userNum == randomNum)
                WriteLine("Computer: {0}\nYou: {1}\n" + "Draw!", computerPick, userPick);
            else
                WriteLine("Computer: {0}\n" +
                          "You: {1}\n" + WinnerDecision(randomNum, userNum),
                          computerPick, userPick );
        }

        static string WinnerDecision(int computerNum, int input)
        {
            string result = "";
            bool computerWin = true;
            
            switch (computerNum)
            { 
                case 0:
                    if (input == 1)
                        computerWin = true;
                    else if (input == 2)
                        computerWin = false;
                    break;
                case 1:
                    if (input == 0)
                        computerWin = false;
                    else if (input == 2)
                        computerWin = true;
                    break;
                case 2:
                    if (input == 0)
                        computerWin = true;
                    else if (input == 1)
                        computerWin = false;
                    break;
            }

            switch (computerWin)
            {
                case true:
                    result += "The computer wins!";
                break;

                case false:
                    result += "You win!";
                break;
            }

            return result;
        }

    }

}
