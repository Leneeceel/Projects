﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter4
{
    class CheckCredit
    {
        static void Main(string[] args)
        {
            decimal priceInput,
                    creditLimit = 5000M;

            Write("Enter a price for an item: ");
            priceInput = Convert.ToDecimal(ReadLine());

            if (priceInput > creditLimit)
                WriteLine("More than the credit limit.");
            else
                WriteLine("Approved");
        }
    }
}