﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter4
{
    class GuessingGame
    {
        static void Main(string[] args)
        {
            Random randomGenerator = new Random();
            int randomNumber,
                min = 1,
                max = 11,
                ranNumInput;
            randomNumber = randomGenerator.Next(min, max);

            Write("Guess a random number (1~10): ");
            ranNumInput = Convert.ToInt32(ReadLine());

            WriteLine("You chose: {0}", ranNumInput);
            WriteLine("Random number is: {0}", randomNumber);

            if (ranNumInput > randomNumber)
                WriteLine("You chose a higher number");
            else if (ranNumInput < randomNumber)
                WriteLine("You chose a lower number");
            else
                WriteLine("You have won!");
        }
    }
}
