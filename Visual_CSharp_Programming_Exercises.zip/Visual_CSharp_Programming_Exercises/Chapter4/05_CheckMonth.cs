﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter4
{
    class CheckMonth
    {
        static void Main(string[] args)
        {
            int birthMonth;

            Write("Enter a birth month: ");
            birthMonth = Convert.ToInt32(ReadLine());

            if (birthMonth > 0 && birthMonth <= 12)
                WriteLine("{0} is a valid month", birthMonth);
            else
                WriteLine("Invalid");
        }
    }
}
