﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter4
{
    class CheckMonth2
    {
        static void Main(string[] args)
        {
            int birthMonth;
            int birthDay;

            Write("Enter a birth month: ");
            birthMonth = Convert.ToInt32(ReadLine());
            Write("Enter a birth day: ");
            birthDay = Convert.ToInt32(ReadLine());

            if (birthMonth == 1 && birthDay >= 1 && birthDay <= 31 ||
                birthMonth == 2 && birthDay >= 1 && birthDay <= 28)
                WriteLine("Valid");
            else
                WriteLine("Invalid");
        }
    }
}
