﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter4
{
    class Lottery
    {
        static void Main(string[] args)
        {
            Random randomNumberGenerator = new Random();
            int firstNum,
                secondNum,
                thirdNum,
                award;

            string first,
                   second,
                   third,
                   userFirst,
                   userSecond,
                   userThird;

            firstNum = randomNumberGenerator.Next(1, 6);
            secondNum = randomNumberGenerator.Next(1, 6);
            thirdNum = randomNumberGenerator.Next(1, 6);

            first = Convert.ToString(firstNum);
            second = Convert.ToString(secondNum);
            third = Convert.ToString(thirdNum);

            WriteLine("Matching Numbers\t\t\t\tAward($)");
            WriteLine("Any one matching\t\t\t\t   10");
            WriteLine("Two matching\t\t\t\t\t  100");
            WriteLine("Three matching, not in order\t\t\t1,000");
            WriteLine("Three matching in exact order\t\t       10,000");
            WriteLine("No matches\t\t\t\t\t    0\n");

            Write("Pick three numbers(1~5). The first one: ");
            userFirst = ReadLine();
            Write("The Second one: ");
            userSecond = ReadLine();
            Write("The third one: ");
            userThird = ReadLine();

            if (first + second + third == userFirst + userSecond + userThird)
                award = 10000;
            else if (Equals(userFirst, first) && Equals(userSecond, third) && Equals(userThird, second) ||
                     Equals(userFirst, second) && Equals(userSecond, third) && Equals(userThird, first) ||
                     Equals(userSecond, first) && Equals(userFirst, second) && Equals(userThird, third) ||
                     Equals(userSecond, second) && Equals(userFirst, third) && Equals(userThird, first))
                award = 1000;
            else if (Equals(userFirst, first) && Equals(userSecond, second) ||
                     Equals(userFirst, first) && Equals(userSecond, third) ||
                     Equals(userFirst, first) && Equals(userThird, second) ||
                     Equals(userFirst, first) && Equals(userThird, third) ||
                     Equals(userFirst, second) && Equals(userSecond, first) ||
                     Equals(userFirst, second) && Equals(userSecond, third) ||
                     Equals(userFirst, second) && Equals(userThird, first) ||
                     Equals(userFirst, second) && Equals(userThird, third) ||
                     Equals(userFirst, third) && Equals(userSecond, second) ||
                     Equals(userFirst, third) && Equals(userSecond, third) ||
                     Equals(userFirst, third) && Equals(userThird, second) ||
                     Equals(userFirst, third) && Equals(userThird, third))
                award = 100;
            else if (Equals(userFirst, first) || Equals(userFirst, second) || Equals(userFirst, third) ||
                     Equals(userSecond, first) || Equals(userSecond, second) || Equals(userSecond, third) ||
                     Equals(userThird, first) || Equals(userThird, second) || Equals(userThird, third))
                award = 10;
            else
                award = 0;

            WriteLine("The random numbers are: {0}\n" +
                      "You picked: {1}", first + second + third, userFirst + userSecond + userThird);
            WriteLine("You won {0}!", award);
        }
    }
}