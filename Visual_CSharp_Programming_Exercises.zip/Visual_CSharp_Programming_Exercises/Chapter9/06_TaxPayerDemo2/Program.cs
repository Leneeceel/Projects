﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace TaxPayerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Taxpayer[] taxpayers = new Taxpayer[10];

            taxpayers[0] = new Taxpayer { SSN = "0000000000", YearlyIncome = 52000 };
            taxpayers[1] = new Taxpayer { SSN = "1111111111", YearlyIncome = 16400 };
            taxpayers[2] = new Taxpayer { SSN = "2222222222", YearlyIncome = 42640 };
            taxpayers[3] = new Taxpayer { SSN = "3333333333", YearlyIncome = 77000 };
            taxpayers[4] = new Taxpayer { SSN = "4444444444", YearlyIncome = 31000 };
            taxpayers[5] = new Taxpayer { SSN = "5555555555", YearlyIncome = 22000 };
            taxpayers[6] = new Taxpayer { SSN = "6666666666", YearlyIncome = 34000 };
            taxpayers[7] = new Taxpayer { SSN = "7777777777", YearlyIncome = 41000 };
            taxpayers[8] = new Taxpayer { SSN = "8888888888", YearlyIncome = 22000 };
            taxpayers[9] = new Taxpayer { SSN = "9999999999", YearlyIncome = 11700 };

            foreach (var item in taxpayers)
                WriteLine("SSN: {0} \tYearly Income: {1:C} \tIncome Tax: {2:C}", item.SSN, item.YearlyIncome, item.IncomeTaxOwed);

            WriteLine("********************************\n\n");
            Sort(taxpayers);

            foreach (var item in taxpayers)
                WriteLine("SSN: {0} \tYearly Income: {1:C} \tIncome Tax: {2:C}", item.SSN, item.YearlyIncome, item.IncomeTaxOwed);


        }
    }
}
