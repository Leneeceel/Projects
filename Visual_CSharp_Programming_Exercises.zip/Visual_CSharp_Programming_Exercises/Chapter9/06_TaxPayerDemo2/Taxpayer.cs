﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxPayerDemo
{
    class Taxpayer : IComparable
    {
        double yearlyIncome;
        double incomeTaxOwed;

        public string SSN { get; set; }
        public double YearlyIncome
        {
            get { return yearlyIncome; }
            set
            {
                yearlyIncome = value;

                if (yearlyIncome < 30000)
                { 
                    incomeTaxOwed = 0.15;
                    incomeTaxOwed *= YearlyIncome;
                }
                else
                {
                    incomeTaxOwed = 0.28;
                    incomeTaxOwed *= YearlyIncome;
                }
            }
        }
        public double IncomeTaxOwed
        {
            get { return incomeTaxOwed; }
        }


        int IComparable.CompareTo(object o)
        {
            int result;

            Taxpayer aTaxpayer = (Taxpayer)o;

            if (this.IncomeTaxOwed > aTaxpayer.IncomeTaxOwed)
                result = 1;
            else if (this.IncomeTaxOwed < aTaxpayer.IncomeTaxOwed)
                result = -1;
            else
                result = 0;

            return result;
        }
    }

}
