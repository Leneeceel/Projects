﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RelativesBirthday
{
    class Relative : IComparable
    {
        public string Name { get; set; }
        public string Relationship { get; set; }
        public int BirthDD { get; set; }
        public int BirthMM { get; set; }
        public int BirthYY { get; set; }

        int IComparable.CompareTo(object o)
        {
            int result = 0;
            Relative aRelative = (Relative)o;

            result = String.Compare(this.Name, aRelative.Name);

            return result;
        }
    }
}
