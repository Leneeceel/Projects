﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace RelativesBirthday
{
    class Program
    {
        static void Main(string[] args)
        {
            Relative[] relatives = new Relative[12];
            string[] birthday;
            Relative name = new Relative();
            int x;

            for (int i = 0; i < relatives.Length; i++)
            {
                relatives[i] = new Relative();
                Write("Enter your relative's name: ");
                relatives[i].Name = ReadLine();
                Write("Enter the relationship to you: ");
                relatives[i].Relationship = ReadLine();
                Write("Enter their birth day (DD-MM-YY): ");
                birthday = ReadLine().Split('-');
                relatives[i].BirthDD = Convert.ToInt32(birthday[0]);
                relatives[i].BirthMM = Convert.ToInt32(birthday[1]);
                relatives[i].BirthYY = Convert.ToInt32(birthday[2]);
                WriteLine("\n\n");
            }

            //relatives[0] = new Relative { Name = "p", Relationship = "p", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[1] = new Relative { Name = "q", Relationship = "q", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[2] = new Relative { Name = "a", Relationship = "a", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[3] = new Relative { Name = "v", Relationship = "v", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[4] = new Relative { Name = "c", Relationship = "c", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[5] = new Relative { Name = "d", Relationship = "d", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[6] = new Relative { Name = "w", Relationship = "w", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[7] = new Relative { Name = "h", Relationship = "h", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[8] = new Relative { Name = "b", Relationship = "b", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[9] = new Relative { Name = "q", Relationship = "q", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[10] = new Relative { Name = "x", Relationship = "x", BirthDD = 22, BirthMM = 22, BirthYY = 22 };
            //relatives[11] = new Relative { Name = "c", Relationship = "c", BirthDD = 22, BirthMM = 22, BirthYY = 22 };

            Sort(relatives);

            WriteLine("{0, -10} {1, -15} {2}", "Name", "Relationship", "Birth");
            foreach (var item in relatives)
            {
                WriteLine("{0, -10} {1, -15} {2}", item.Name, item.Relationship, item.BirthDD + "--" + item.BirthMM + "--" + item.BirthYY);
            }

            WriteLine("\n\n");

            WriteLine("Enter your relative's name: ");
            name.Name = ReadLine().ToLower();

            x = BinarySearch(relatives, name);
            WriteLine("\n");
            if (x < 0)
                WriteLine("The person was not found.");
            else
                WriteLine("{0, -10} {1, -15} {2}", relatives[x].Name, relatives[x].Relationship, 
                                                   relatives[x].BirthDD + "--" + relatives[x].BirthMM + "--" + relatives[x].BirthYY);
        }
    }
}
