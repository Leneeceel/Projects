﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace FractionDemo3
{
    class Program
    {
        static void Main(string[] args)
        {
            Fraction[] fractionArray = new Fraction[4];

            for (int i = 0; i < fractionArray.Length; i++)
            {
                Write("Enter a whole number, a numerator, and a denominator\n" +
                      "Ex) 2 2/4\n");
                string input = ReadLine();

                fractionArray[i] = new Fraction();
                fractionArray[i].WholeNum = Convert.ToDouble(input.Substring(0, 1));
                fractionArray[i].Numerator = Convert.ToDouble(input.Substring(2, 1));
                fractionArray[i].Denominator = Convert.ToDouble(input.Substring(4, 1));
            }

            WriteLine("Numbers are: ");
            foreach (var items in fractionArray)
                Write("{0}\t", items.Display());



        }
    }
}
