﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FractionDemo
{
    class Fraction
    {
        double denominator;
        public double WholeNum { get; set; }
        public double Numerator { get; set; }
        public double Denominator
        {
            get { return denominator; }
            set
            {
                if (value > 0)
                    denominator = value;
                else
                    denominator = 1;
            }
        }

        public Fraction(double wholeNum, double numerator, double denominator)
        {
            WholeNum = wholeNum;
            Numerator = numerator;
            Denominator = denominator;
        }
        public Fraction(double numerator, double denominator)
        {
            WholeNum = 0;
            Numerator = numerator;
            Denominator = denominator;
        }
        public Fraction()
        {
            WholeNum = 0;
            Numerator = 0;
            Denominator = 1;
        }

        public void Reduce()
        {
            double remainder,
                   a,
                   b;

            a = Numerator;
            b = Denominator;

            while (b != 0)
            {
                remainder = a % b;
                a = b;
                b = remainder;
            }

            Numerator /= a;
            Denominator /= a;
        }

        public static Fraction operator+(Fraction num1, Fraction num2)
        {
            Fraction convertedNum1 = new Fraction();
            Fraction convertedNum2 = new Fraction();
            Fraction result = new Fraction();

            convertedNum1.Numerator = (num1.WholeNum * num1.Denominator + num1.Numerator) * num2.Denominator;
            convertedNum1.Denominator = num1.Denominator * num2.Denominator;
            
            convertedNum2.Numerator = (num2.WholeNum * num2.Denominator + num2.Numerator) * num1.Denominator;
            convertedNum2.Denominator = num1.Denominator * num2.Denominator;
            
            result.Numerator = convertedNum1.Numerator + convertedNum2.Numerator;
            result.Denominator = convertedNum1.Denominator;
            result.WholeNum = Math.Truncate(result.Numerator / result.Denominator);
            result.Numerator = (convertedNum1.Numerator + convertedNum2.Numerator) % result.Denominator;

            result.Reduce();
            return result;
        }

        public static Fraction operator*(Fraction num1, Fraction num2)
        {
            Fraction convertedNum1 = new Fraction();
            Fraction convertedNum2 = new Fraction();
            Fraction result = new Fraction();

            convertedNum1.Numerator = num1.WholeNum * num1.Denominator + num1.Numerator;
            convertedNum2.Numerator = num2.WholeNum * num2.Denominator + num2.Numerator;

            result.Numerator = convertedNum1.Numerator * convertedNum2.Numerator;
            result.Denominator = num1.Denominator * num2.Denominator;
            result.WholeNum = Math.Truncate(result.Numerator / result.Denominator);
            result.Numerator %= result.Denominator;

            result.Reduce();
            return result;
        }

        public string Display()
        {
            string result;

            result = String.Format("{0} {1}", WholeNum > 0 ? Convert.ToString(WholeNum) : "", Numerator > 0 ? Convert.ToString(Numerator + "/" + Denominator) : "");

            return result;
        }
    }
}
