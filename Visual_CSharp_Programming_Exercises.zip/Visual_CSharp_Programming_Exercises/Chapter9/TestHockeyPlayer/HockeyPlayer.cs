﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestHockeyPlayer
{
    class HockeyPlayer
    {
        string name;
        int jerseyNum;
        int goalsScored;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public int JerseyNum
        {
            get { return jerseyNum; }
            set { jerseyNum = value; }
        }

        public int GoalsScored
        {
            get { return goalsScored; }
            set { goalsScored = value; }
        }
    }
}
