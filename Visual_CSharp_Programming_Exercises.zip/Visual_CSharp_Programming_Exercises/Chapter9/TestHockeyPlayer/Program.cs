﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestHockeyPlayer
{
    class Program
    {
        static void Main(string[] args)
        {
            HockeyPlayer aPlayer = new HockeyPlayer();

            aPlayer.Name = "aPlayer";
            aPlayer.JerseyNum = 22;
            aPlayer.GoalsScored = 5;

            Console.WriteLine("{0}  {1}  {2}", aPlayer.Name, aPlayer.JerseyNum, aPlayer.GoalsScored);
                
        }
    }
}
