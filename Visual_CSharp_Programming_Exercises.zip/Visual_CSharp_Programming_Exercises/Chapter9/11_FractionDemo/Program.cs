﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace FractionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Fraction num = new Fraction(1, 1, 4);
            Fraction num2 = new Fraction(1, 2, 4);

            WriteLine("{0} {1},{2}", num.WholeNum, num.Numerator, num.Denominator);
            WriteLine("{0} {1},{2}", num2.WholeNum, num2.Numerator, num2.Denominator);

            num2.Reduce();
            WriteLine("{0} {1},{2}", num2.WholeNum, num2.Numerator, num2.Denominator);

            Fraction num3 = new Fraction();
            num3 = num + num2;

            WriteLine(num3.Display());
        }
    }
}
