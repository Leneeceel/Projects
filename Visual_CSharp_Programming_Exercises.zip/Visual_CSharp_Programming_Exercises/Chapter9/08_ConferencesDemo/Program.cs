﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace ConferencesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Conference[] conferences = new Conference[5];

            for (int i = 0; i < conferences.Length; i++)
            {
                conferences[i] = new Conference();
                Write("Enter a conference name: ");
                conferences[i].Name = ReadLine();
                Write("Enter a starting date: ");
                conferences[i].StartingDate = ReadLine();
                Write("Enter a number of attendees: ");
                conferences[i].NumOfAttendees = Convert.ToInt32(ReadLine());
                WriteLine("\n\n");
            }

            foreach (var item in conferences)
                WriteLine("{0} \t {1} \t {2}", item.Name, item.StartingDate, item.NumOfAttendees);
            WriteLine("\n\n");

            Sort(conferences);
            foreach (var item in conferences)
                WriteLine("{0} \t {1} \t {2}", item.Name, item.StartingDate, item.NumOfAttendees);
        }
    }
}
