﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConferencesDemo
{
    class Conference : IComparable
    {
        public string Name { get; set; }
        public string StartingDate { get; set; }
        public int NumOfAttendees { get; set; }

        public Conference()
        {

        }

        int IComparable.CompareTo(object o)
        {
            int result;
            Conference aConference = (Conference)o;

            if (this.NumOfAttendees > aConference.NumOfAttendees)
                result = 1;
            else if (this.NumOfAttendees < aConference.NumOfAttendees)
                result = -1;
            else
                result = 0;
            return result;
        }
    }
}
