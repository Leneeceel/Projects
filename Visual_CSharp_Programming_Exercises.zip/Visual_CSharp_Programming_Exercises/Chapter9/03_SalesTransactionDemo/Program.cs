﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTransactionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            SalesTransaction aPerson = new SalesTransaction("aName", 120, 0.04);
            SalesTransaction anotherPerson = new SalesTransaction("anotherName", 400);

            SalesTransaction total = new SalesTransaction();
            total = aPerson + anotherPerson;

            Console.WriteLine("{0}\n{1}\n{2}\n{3}", total.Name, total.Amount, total.Commission, total.CommissionRate);

        }
    }
}
