﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SalesTransactionDemo
{
    class SalesTransaction
    {
        string name;
        double amount;
        double commission;
        double commissionRate;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public double Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        public double Commission
        {
            get { return commission; }
            set { commission = value; }
        }

        public double CommissionRate
        {
            get { return commissionRate; }
        }

        public SalesTransaction()
        {

        }
        public SalesTransaction(string name, double amount, double commissionRate)
        {
            Name = name;
            Amount = amount;
            Commission = Amount * commissionRate;
        }

        public SalesTransaction(string name, double amount)
        {
            Name = name;
            Amount = amount;
            commissionRate = 0;
        }

        public SalesTransaction(string name)
        {
            Name = name;
            Amount = 0;
            Commission = 0;
            commissionRate = 0;
        }

        public static SalesTransaction operator+(SalesTransaction aPerson, SalesTransaction anotherPerson)
        {
            SalesTransaction total = new SalesTransaction();
            total.Name = "Name";
            total.Amount = aPerson.Amount + anotherPerson.Amount;
            total.Commission = aPerson.Commission + anotherPerson.Commission;
            total.commissionRate = aPerson.CommissionRate + anotherPerson.CommissionRate;

            return total;
        }
    }

}
