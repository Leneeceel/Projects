﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShirtDemo
{
    class Shirt
    {
        public string Material { get; set; }
        public string Colour { get; set; }
        public int Size { get; set; }

        public void GetInfo(Shirt[] shirts)
        {
            foreach (var item in shirts)
                Console.WriteLine("{0}\n", item);
        }
    }
}
