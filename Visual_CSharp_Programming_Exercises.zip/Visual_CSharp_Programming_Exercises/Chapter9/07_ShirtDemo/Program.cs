﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShirtDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Shirt aShirt = new Shirt { Material = "material_a", Colour = "colour_a", Size = 1 };
            Shirt bShirt = new Shirt { Material = "material_b", Colour = "colour_b", Size = 2 };
            Shirt cShirt = new Shirt { Material = "material_c", Colour = "colour_c", Size = 3 };
            Shirt dShirt = new Shirt { Material = "material_d", Colour = "colour_d", Size = 4 };
            Shirt eShirt = new Shirt { Material = "material_e", Colour = "colour_e", Size = 5 };
            Shirt fShirt = new Shirt { Material = "material_f", Colour = "colour_f", Size = 6 };

            GetInfo(aShirt);
            Stars();
            GetInfo(aShirt, cShirt, dShirt);

        }

        static void GetInfo(params Shirt[] shirts)
        {
            foreach (var item in shirts)
                Console.WriteLine("{0} \t {1} \t {2}\n", item.Material, item.Colour, item.Size);
        }

        static void Stars()
        {
            Console.WriteLine("***********************");
            Console.WriteLine("***********************");
        }
    }
}
