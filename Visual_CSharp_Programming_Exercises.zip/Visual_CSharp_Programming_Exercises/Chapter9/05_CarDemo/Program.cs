﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Car aCar = new Car("aModel", 50);
            Car bCar = new Car("bModel");

            Console.WriteLine("{0}  {1}", aCar.Model, aCar.MilesPerGallon);
            Console.WriteLine("{0}  {1}", bCar.Model, bCar.MilesPerGallon);

            aCar++;
            bCar++;
            Console.WriteLine("{0}  {1}", aCar.Model, aCar.MilesPerGallon);
            Console.WriteLine("{0}  {1}", bCar.Model, bCar.MilesPerGallon);
        }
    }
}
