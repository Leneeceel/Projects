﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CarDemo
{
    class Car
    {
        string model;
        double milesPerGallon;

        public string Model
        {
            get { return model; }
            set { model = value; }
        }

        public double MilesPerGallon
        {
            get { return milesPerGallon; }
            set { milesPerGallon = value; }
        }

        public Car()
        {

        }

        public Car(string model, double milesPerGallon)
        {
            Model = model;
            MilesPerGallon = milesPerGallon;
        }

        public Car(string model)
        {
            Model = model;
            MilesPerGallon = 20;
        }
        
        public static Car operator++(Car aCar)
        {
            aCar.MilesPerGallon++;
            Console.WriteLine("{0} Incremented", aCar.model);

            return aCar;
        }
    }
}