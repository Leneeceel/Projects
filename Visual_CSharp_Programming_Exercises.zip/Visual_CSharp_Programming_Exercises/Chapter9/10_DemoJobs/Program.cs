﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace DemoJobs
{
    class Program
    {
        static void Main(string[] args)
        {
            Job aJob = new Job { Description = "A thing", NumOfHours = 5, PayPerHour = 20 };
            Job anotherJob = new Job { Description = "Another thing", NumOfHours = 10, PayPerHour = 30 };
            Job newJob = new Job();
            newJob = aJob + anotherJob;

            WriteLine("A job");
            WriteLine("{0}\nHours: {1}\nPay per hour: {2:C}\nTotal: {3:C}\n\n", aJob.Description, aJob.NumOfHours, aJob.PayPerHour, aJob.TotalFee);

            WriteLine("Another job");
            WriteLine("{0}\nHours: {1}\nPay per hour: {2:C}\nTotal: {3:C}\n\n", anotherJob.Description, anotherJob.NumOfHours,
                                                                            anotherJob.PayPerHour, anotherJob.TotalFee);

            WriteLine("New job");
            WriteLine("{0}\nHours: {1}\nPay per hour: {2:C}\nTotal: {3:C}", newJob.Description, newJob.NumOfHours, newJob.PayPerHour, newJob.TotalFee);
        }
    }
}
