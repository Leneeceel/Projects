﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoJobs
{
    class Job
    {
        public string Description { get; set; }
        double numOfHours;
        double payPerHour;
        double totalFee;

        public double NumOfHours
        {
            get { return numOfHours; }
            set
            {
                numOfHours = value;
                CalcTotal();
            }
        }
        public double PayPerHour
        {
            get { return payPerHour; }
            set
            {
                payPerHour = value;
                CalcTotal();
            }
        }
        public double TotalFee
        {
            get { return totalFee; }
        }
        
        private void CalcTotal()
        {
            totalFee = NumOfHours * PayPerHour;
        }
        private void CalcTotal(Job aJob, Job anotherJob)
        {
            totalFee = aJob.NumOfHours * aJob.PayPerHour + anotherJob.NumOfHours * anotherJob.PayPerHour;
        }

        public static Job operator+(Job aJob, Job anotherJob)
        {
            Job newJob = new Job();

            newJob.Description = aJob.Description + " and " + anotherJob.Description;
            newJob.NumOfHours = aJob.NumOfHours + anotherJob.NumOfHours;
            newJob.CalcTotal(aJob, anotherJob);
            newJob.PayPerHour = newJob.TotalFee / newJob.numOfHours;

            return newJob;
        }
    }
}
