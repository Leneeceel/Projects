﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TilingDemo
{
    class Room
    {
        int length,
            width,
            numOfBoxes;
        int area;

        public int Length
        {
            get { return length; }
            set
            {
                length = value;
                CalcArea(length, width);
                CalcBoxes(area);
            }
        }

        public int Width
        {
            get { return width; }
            set
            {
                width = value;
                CalcArea(length, width);
                CalcBoxes(area);
            }
        }

        public int Area
        {
            get { return area; }
        }

    public int NumOfBoxes
        {
            get { return numOfBoxes; }
        }

        public Room(int length, int width)
        {
            Length = length;
            Width = width;
        }

        private void CalcArea(int length, int width)
        {
            area = length * width;
        }
        private void CalcBoxes(int area)
        {
            numOfBoxes = (area / 12) + 2; 
        }
    }
}
