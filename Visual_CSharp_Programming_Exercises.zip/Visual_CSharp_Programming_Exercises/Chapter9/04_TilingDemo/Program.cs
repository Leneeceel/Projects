﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TilingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Room[] roomArray = new Room[10];
            int width = 3,
                length = 5;

            for (int i = 0; i < roomArray.Length; i++)
            {
                roomArray[i] = new Room(length, width);
                length += 2;
                width += 2;
            }

            foreach (var item in roomArray)
                Console.WriteLine("Length: {0} Width: {1}  Area: {2}  Number of boxes: {3}", item.Length, item.Width, item.Area, item.NumOfBoxes);
        }
        
    }
}
