﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace TestClassifiedAd
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassifiedAd anAd = new ClassifiedAd();

            anAd.Category = "cars";
            anAd.ANumOfWords = 5;

            WriteLine("{0} {1} {2:C}", anAd.Category, anAd.ANumOfWords, anAd.Price);
        }
    }
}
