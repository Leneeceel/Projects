﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestClassifiedAd
{
    class ClassifiedAd
    {
        string category;
        int aNumOfWords;
        double price;

        public string Category
        {
            get { return category; }
            set { category = value; }
        }

        public int ANumOfWords
        {
            get { return aNumOfWords; }
            set
            {
                aNumOfWords = value;
                CalcPrice(aNumOfWords);
            }
        }

        public double Price
        {
            get { return price; }
            
        }
        
        private void CalcPrice(int aNumOfWords)
        {
            price = aNumOfWords * 0.90;
        }
    }
}
