﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxPayerDemo
{
    class Taxpayer
    {
        double yearlyIncome;
        double incomeTaxOwed;

        public string SSN { get; set; }
        public double YearlyIncome
        {
            get { return yearlyIncome; }
            set
            {
                yearlyIncome = value;

                if (yearlyIncome < 30000)
                { 
                    incomeTaxOwed = 0.15;
                    incomeTaxOwed *= YearlyIncome;
                }
                else
                {
                    incomeTaxOwed = 0.28;
                    incomeTaxOwed *= YearlyIncome;
                }
            }
        }
        public double IncomeTaxOwed
        {
            get { return incomeTaxOwed; }
        }


    }
}
