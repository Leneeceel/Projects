﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class DoubleDecimalTest
    {
        static void Main(string[] args)
        {
            double aNumber;
            decimal anotherNumber;

            aNumber = 1.1111;
            anotherNumber = 1;

            //Error
            //anotherNumber = 1.11;

            Console.WriteLine("A number is a double, another number is a decimal\n" +
                              "A number: {0}\nAnother Number: {1}", aNumber, anotherNumber);
        }
    }
}
