﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class Tests
    {
        static void Main(string[] args)
        {
            decimal testA;
            decimal testB;
            decimal testC;
            decimal testD;
            decimal testF;
            decimal average;

            testA = 70;
            testB = 64;
            testC = 73;
            testD = 65;
            testF = 85;
            average = (testA + testB + testC + testD + testF) / 5;

            Console.WriteLine("Your scores are: {0} {1} {2} {3} {4}", 
                               testA, testB, testC, testD, testF);
            Console.WriteLine("Your average score is: {0}", average);
        }
    }
}
