﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class PigLatin
    {
        static void Main(string[] args)
        {
            string wordInput;
            string translatedWord;

            Console.Write("Enter a word: ");
            wordInput = Console.ReadLine();

            translatedWord =  wordInput.Substring(1, wordInput.Length -1 )
                              + wordInput.Substring(0,1)
                              + "ay";

            Console.WriteLine("The word is {0} in Pig Latin.", translatedWord);
        }
    }
}
