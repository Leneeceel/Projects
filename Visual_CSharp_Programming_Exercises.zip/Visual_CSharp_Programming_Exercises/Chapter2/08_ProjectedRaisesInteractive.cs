﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class ProjectedRaisesInteractive
    {
        static void Main(string[] args)
        {
            decimal raise = 0.04M;
            //decimal bobSalary = 3000.00M;
            //decimal lucySalary = 2000.00M;
            //decimal mySalary = 100000.00M;
            //decimal bobSalaryNextYear;
            //decimal lucySalaryNextYear; 
            //decimal mySalaryNextYear;
            decimal salary;
            decimal salaryNextYear;

            //Console.WriteLine("Current Salaries\nBob: {0:C}\nLucy: {1:C}\nMe: {2:C}\n",
            //                   bobSalary, lucySalary, mySalary);
            Console.Write("Enter your salary: ");
            salary = Convert.ToDecimal(Console.ReadLine());

            //bobSalaryNextYear = SalaryCalculated(bobSalary, raise);
            //lucySalaryNextYear = SalaryCalculated(lucySalary, raise);
            //mySalaryNextYear = SalaryCalculated(mySalary, raise);
            salaryNextYear = SalaryCalculated(salary, raise);

            //Console.WriteLine("The expected salaries next year\nBob: {0:C}\nLucy: {1:C}\nMe: {2:C}",
            //                   bobSalaryNextYear, lucySalaryNextYear, mySalaryNextYear);

            Console.WriteLine("Your salary next year: {0}", salaryNextYear);
        }

        static decimal SalaryCalculated(decimal num, decimal raise)
        {
            num += (num * raise);

            return num;
        }
    }
}
