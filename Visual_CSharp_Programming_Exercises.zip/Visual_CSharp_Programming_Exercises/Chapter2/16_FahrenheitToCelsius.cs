﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class FahrenheitToCelsius
    {
        static void Main(string[] args)
        {
            decimal fahrenheitInput;
            decimal conversion = 5 / 9M;

            Console.Write("Enter a temperature in Fahrenheit: ");
            fahrenheitInput = Convert.ToDecimal(Console.ReadLine());

            Console.WriteLine("{0} Fahrenheit is {1:F2} Celsius.", fahrenheitInput, (fahrenheitInput - 32) * conversion);

        }
    }
}
