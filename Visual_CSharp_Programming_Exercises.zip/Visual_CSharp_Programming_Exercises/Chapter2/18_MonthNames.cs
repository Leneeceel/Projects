﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class MonthNames
    {
        static void Main(string[] args)
        {
            int monthInNum;

            Console.Write("Enter a month in a number:");
            monthInNum = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("That is {0}", (Month)monthInNum);

            //Console.WriteLine((int)Month.DECEMBER);
            //12
        }

        enum Month
        {
            JANUARY = 1,
            FEBRUARY,
            MARCH,
            APRIL,
            MAY,
            JUNE,
            JULY,
            AUGUST,
            SEPTEMBER,
            OCTOBER,
            NOVEMBER,
            DECEMBER
        }
    }

}
