﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class MilesToKilometres
    {
        static void Main(string[] args)
        { 
        decimal numOfKmInMile = 1.6M;
        int distanceInMiles = 4;

        decimal kmDisplayed = numOfKmInMile * distanceInMiles;
        double mileDisplayed = distanceInMiles;
        

        Console.WriteLine("{0} miles is {1} km", mileDisplayed, kmDisplayed);
        }
    }
}
