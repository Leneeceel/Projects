﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class Payroll
    {
        static void Main(string[] args)
        {
            string name,
                   ssn;
            decimal hourlyPay;
            int hrsWorked;
            decimal grossPay;
            decimal fedralWithholding;
            decimal stateWithholding;
            decimal netPay;

            Console.Write("Enter your name: ");
            name = Console.ReadLine();
            Console.Write("Social Security Number: ");
            ssn = Console.ReadLine();
            Console.Write("Hourly pay rate: ");
            hourlyPay = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Hours worked: ");
            hrsWorked = Convert.ToInt32(Console.ReadLine());

            grossPay = hrsWorked * hourlyPay;
            fedralWithholding = grossPay * 0.15M;
            stateWithholding = grossPay * 0.05M;
            netPay = grossPay - fedralWithholding - stateWithholding;

            Console.WriteLine("\nPayroll summary for: {0}\n" +
                              "SSN: {1}\n" +
                              "You worked {2} hours at {3} per hour", name, ssn, hrsWorked, hourlyPay);

            Console.WriteLine("\nGross pay: {0, 29:C2}\n" +
                              "Fedral withholding: {1, 20:C2}\n" +
                              "State withholding: {2, 21:C2}\n" +
                              "----------------------------------------\n" +
                              "Net pay: {3, 31:C2}", grossPay, fedralWithholding, stateWithholding, netPay);
        }
    }
}
