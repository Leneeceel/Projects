﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class HoursAndMinutes
    {
        static void Main(string[] args)
        {
            int minutes;

            Console.Write("Enter how many minutes: ");
            minutes = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("{0} minutes is {1} hours and {2} minutes", minutes, minutes/60, minutes%60);

            
        }
    }
}
