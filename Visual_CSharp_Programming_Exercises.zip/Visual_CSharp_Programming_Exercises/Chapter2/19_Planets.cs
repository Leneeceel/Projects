﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class Planets
    {
        static void Main(string[] args)
        {
            int planetPosition;

            Console.Write("Pick a numeric position of a planet: ");
            planetPosition = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("That is {0}", (Planet)planetPosition);

            //Console.WriteLine("{0}", (int)Planet.EARTH);
            //3
        }

        enum Planet
        {
            MERCURY = 1,
            VENUS,
            EARTH,
            MARS,
            JUPITER,
            SATURN,
            URANUS,
            NEPTUNE
        }
    }
    
}
