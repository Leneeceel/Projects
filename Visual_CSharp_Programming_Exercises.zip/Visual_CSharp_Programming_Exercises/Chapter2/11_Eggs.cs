﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class Eggs
    {
        static void Main(string[] args)
        {
            int eggsFromA = 3;
            int eggsFromB = 3;
            int eggsFromC = 3;
            int eggsFromD = 4;

            int numOfEggs = eggsFromA + eggsFromB + eggsFromC + eggsFromD;

            Console.WriteLine("Total number of eggs: {0}\n{1} dozen and {2} eggs", numOfEggs, numOfEggs/12, numOfEggs%12);
        }
    }
}
