﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class Dollars
    {
        static void Main(string[] args)
        {
            int moneyInput;
            int numOfTwenties;
            int numOfTens;
            int numOfToonies;
            int numOfLoonies;
            string delimeter = "|";
            Console.Write("How much money? ");
            moneyInput = Convert.ToInt32(Console.ReadLine());

            numOfTwenties = moneyInput / 20;
            numOfTens = (moneyInput % 20) / 10;
            numOfToonies = (moneyInput % 10) / 2;
            numOfLoonies = moneyInput % 2;

            Console.WriteLine("20s: {0} {1} 10s: {2} {1} Toonies: {3} {1} Loonies: {4} {1}", 
                               numOfTwenties, delimeter, numOfTens, numOfToonies, numOfLoonies );
        }
    }
}
