﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class EggsInteractive
    {
        static void Main(string[] args)
        {
            int eggsFromA;
            int eggsFromB;
            int eggsFromC;
            int eggsFromD;

            Console.Write("How many eggs are from A: ");
            eggsFromA = Convert.ToInt32(Console.ReadLine());
            Console.Write("How many eggs are from A: ");
            eggsFromB = Convert.ToInt32(Console.ReadLine());
            Console.Write("How many eggs are from A: ");
            eggsFromC = Convert.ToInt32(Console.ReadLine());
            Console.Write("How many eggs are from A: ");
            eggsFromD = Convert.ToInt32(Console.ReadLine());
            int numOfEggs = eggsFromA + eggsFromB + eggsFromC + eggsFromD;

            Console.WriteLine("Total number of eggs: {0}\n{1} dozen and {2} eggs", numOfEggs, numOfEggs/12, numOfEggs%12);
        }
    }
}
