﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Visual_CSharp_Programming_Exercises
{
    class CarRental
    {
        static void Main(string[] args)
        {
            decimal costPerDay = 20M;
            decimal costPerMile = 0.25M;
            int numOfDays;
            decimal milesDriven;

            Console.Write("Enter how many days you want to rent:");

            numOfDays = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter how many miles are driven:");
            milesDriven = Convert.ToDecimal(Console.ReadLine());

            Console.WriteLine("Total cost is {0:C}", costPerDay * numOfDays + costPerMile * milesDriven);

        }
    }
}
