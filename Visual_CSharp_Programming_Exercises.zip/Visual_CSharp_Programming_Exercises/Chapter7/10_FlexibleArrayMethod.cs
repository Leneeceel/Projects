﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class FlexibleArrayMethod
    {
        static void Main(string[] args)
        {
            int[] intArray1 = { 1, 2, 3 };
            int[] intArray2 = { 4, 5, 6, 7 };
            int[] intArray3 = { 8, 9, 10, 11 };

            Result(intArray1);
            Stars();
            Result(intArray2);
            Stars();
            Result(intArray3);
        }

        static void Result(int[] intArray)
        {
            int sum = 0;
            WriteLine("Numbers are:");
            foreach (int num in intArray)
            { 
                sum += num;
                Write("  {0}  ", num);
            }
            WriteLine();
            WriteLine("The sum is: {0}", sum);
        }

        static void Stars()
        {
            WriteLine("******");
        }
    }
}
