﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter7
{
    class SalesLetter
    {
        static void Main(string[] args)
        {
            Console.WriteLine("blahblah");
            DisplayContactInfo();
            Console.WriteLine("blah");
            Console.WriteLine("blahblah");
            DisplayContactInfo();
            Console.WriteLine("blah");
            Console.WriteLine("blahblah");
            Console.WriteLine("blah");
            Console.WriteLine("blahblah");
            Console.WriteLine("blah");
            Console.WriteLine("blahblah");
            DisplayContactInfo();
        }

        static void DisplayContactInfo()
        {
            WriteLine("Phone Number: 123123");
            WriteLine("Cell Number: 123123123");
            WriteLine("Email Address: asdfasdf@asdf.asdf");
        }
    }
}
