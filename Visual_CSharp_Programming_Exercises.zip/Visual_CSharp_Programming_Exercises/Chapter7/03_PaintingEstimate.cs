﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter7
{
    class PaintingEstimate
    {
        static void Main(string[] args)
        {
            decimal length,
                    width;

            Write("Enter length: ");
            length = Convert.ToDecimal(ReadLine());
            Write("Enter width: ");
            width = Convert.ToDecimal(ReadLine());
            
            WriteLine("\nThe total price is: {0:C}", PriceCalc(length, width));


        }

        static decimal PriceCalc(decimal length, decimal width)
        {
            decimal total;
            const int HIEGHT = 9;
            const int PRICE_PER_SQUARE_FOOT = 6;
            total = (((HIEGHT * length) + (HIEGHT * width)) * 2) * PRICE_PER_SQUARE_FOOT; 

            return total;
        }
        
    }
}
