﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter7
{
    class FortuneTeller
    {
        static void Main(string[] args)
        {
            string[] fortune = { "You will die tomorrow.", "You will not die tomorrow.", "You will be dead tomorrow.",
                                 "You will not be dead tomorrow.", "Something happens.", "Something doesn't happen." };

            int randomNum1,
                randomNum2;

            Random randomNumGenerator = new Random();

            randomNum1 = randomNumGenerator.Next(1, 6);
            randomNum2 = randomNumGenerator.Next(1, 6);

            DisplayFortune(fortune[randomNum1], fortune[randomNum2]);
        }

        static void DisplayFortune(string a, string b)
        {
            WriteLine(a);
            WriteLine();
            WriteLine(b);
        }
    }
}
