﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter7
{
    class Multiplication
    {
        static void Main(string[] args)
        {
            int input;
            Write("Enter a number: ");
            input = Convert.ToInt32(ReadLine());

            DisplayMultiplicationTable(input);
        }

        static void DisplayMultiplicationTable(int input)
        {
            int[] multipliedNumbers = new int[9];
            int counter = 2;
            for (int i = 0; i < 9; i++)
                multipliedNumbers[i] = input * (i+2);
            
            foreach (int item in multipliedNumbers)
                WriteLine("{0} * {1} = {2}", input, counter++, item);
        }
    }
}
