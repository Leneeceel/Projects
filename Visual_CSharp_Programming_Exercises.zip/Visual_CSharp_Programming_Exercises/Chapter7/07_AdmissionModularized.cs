﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter4
{
    class Admission
    {
        static void Main(string[] args)
        {
            double grade,
                   admissionTestScore;
            string result;

            Write("Enter a high school grade average: ");
            grade = Convert.ToDouble(ReadLine());
            Write("Enter an admission test score: ");
            admissionTestScore = Convert.ToDouble(ReadLine());

            result = AdmissionResult(grade, admissionTestScore);
            WriteLine(result);
        }

        static string AdmissionResult(double grade, double admissionScore)
        {
            string result;
            if (grade >= 3.0 && admissionScore >= 60 || grade < 3.0 && admissionScore > 80)
                result = "Acceptable";
            else
                result = "Reject";


            return result;
        }
    }
}
