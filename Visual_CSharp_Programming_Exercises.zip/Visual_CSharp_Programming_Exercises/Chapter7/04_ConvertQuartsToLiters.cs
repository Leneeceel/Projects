﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter7
{
    class ConvertQuartsToLiters
    {
        static void Main(string[] args)
        {
            double numOfQuarts;

            Write("Enter quarts: ");
            numOfQuarts = Convert.ToDouble(ReadLine());

            WriteLine("\n{0} quarts is {1:F2}", numOfQuarts, Converter(numOfQuarts));


        }

        static double Converter(double quarts)
        {
            double liter;

            liter = quarts * 0.966353;

            return liter;
        }
    }
}
