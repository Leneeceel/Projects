﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Chapter5
{
    class CountVowels
    {
        static void Main(string[] args)
        {
            string input;

            int numOfVowels = 0;

            Write("Say something!\n");
            input = ReadLine();

            numOfVowels = VowelCounter(input);

            WriteLine("There {0} {1} vowel{2} in it!", numOfVowels > 1 ? "are" : "is",
                                                       numOfVowels,
                                                       numOfVowels > 1 ? "s" : "");
        }

        static int VowelCounter(string word)
        {
            int numOfVowels = 0;
            string[] vowels = { "a", "e", "i", "o", "u" };

            for (int i = 0; i < word.Length; i++)
            {
                for (int ii = 0; ii < vowels.Length; ii++)
                    if (word.Substring(i, 1) == vowels[ii])
                        numOfVowels++;
            }

            return numOfVowels;
        }
    }
}
