﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class Auction
    {
        static void Main(string[] args)
        {
            string item;
            //string[] splittedItem;

            Write("Enter an amount bid: ");
            item = ReadLine();

            if (double.TryParse(item, out double result))
                AcceptBid(result);
            else
                AcceptBid(item);

            //    splittedItem = item.Split(' ');
            //    WriteLine(splittedItem[splittedItem.Length - 1]);
        }

        //static void AcceptBid(string bid)
        //{
        //    const string dollars = "dollars";
        //    bid = bid.ToLower();
        //    isMatch();
        //}

        static void AcceptBid(int bid)
        {
            if (bid < 10)
                WriteLine("It is not an acceptable amount.\n");
            else
                WriteLine("The bid is: {0}", bid);
        }

        static void AcceptBid(double bid)
        {
            if (bid < 10)
                WriteLine("It is not an acceptable amount.\n");
            else
                WriteLine("The bid is: {0}", bid);
        }

        static void AcceptBid(string bid)
        {
            const string dollars = "dollars";
            bid = bid.ToLower();
            double bidDisplayed = 0;
            bool isCorrectFormat = false;

            for (int i = 0; i < bid.Length; i++)
            {
                if (bid.Substring(i, bid.Length - i) == dollars)
                {

                    if (double.TryParse(bid.Substring(0, i), out double result))
                    {
                        isCorrectFormat = true;
                        i = bid.Length;
                        bidDisplayed = result;
                    }
                    else
                        isCorrectFormat = false;
                }
            }

            if (Equals(bid.Substring(0, 1), "$"))
            { 
                bidDisplayed = Convert.ToDouble(bid.Substring(1, bid.Length - 1));
                isCorrectFormat = true;
            }

            if (!isCorrectFormat)
                WriteLine("Incorrect format");
            else if (bidDisplayed < 10)
                WriteLine("It is not an acceptable amount.\n");
            else
                WriteLine("The bid is: {0}", bidDisplayed);

        }

    }
}
