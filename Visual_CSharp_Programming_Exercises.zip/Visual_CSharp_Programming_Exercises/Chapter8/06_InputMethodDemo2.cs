﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class InputMethodDemo
    {
        static void Main(string[] args)
        {
            int first, second;
            InputMethod(out first, out second);
            WriteLine("After InputMethod first is {0}", first);
            WriteLine("and second is {0}", second);
        }

        private static void InputMethod(out int one, out int two)
        {
            one = DataEntry("first");
            two = DataEntry("Second");
        }

        static int DataEntry(string word)
        {
            int num;
            Write("Enter {0} integer: ", word);
            num = Convert.ToInt32(ReadLine());

            return num;
        }
    }
}
