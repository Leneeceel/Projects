﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class IntegerFacts
    {
        static void Main(string[] args)
        {
            int[] intArray = new int[3];
            int highest = 0,
                lowest = 0,
                sum = 0,
                average = 0;

            Border("Filling the array");
            NumberCaller(ref intArray);
            Border("Filling the array ends");
            WriteLine();
            WriteLine();

            Border("Displaying the numbers in the array");
            foreach (int num in intArray)
                Write("{0}  ", num > 0? Convert.ToString(num): "");
            WriteLine();
            Border("Displaying ends");
            WriteLine();
            WriteLine();

            Border("Choosing the highest, the lowest, the sum, the average numbers");
            NumberPicker(ref intArray, out highest, out lowest, out sum, out average);
            WriteLine();
            Border("Choosing the numbers ends");
            WriteLine();
            Border("Displaying the numbers");
            WriteLine("The highest number: {0}\n" +
                      "The lowest number:  {1}\n" +
                      "The sum:            {2}\n" +
                      "The average:        {3}", highest, lowest, sum, average);
            Border("Displaying ends");

        }

        private static void NumberCaller(ref int[] intArray)
        {
            const char QUIT = 'Q';
            string input = " ";
            int numberInput;
            int arrayPosition = 0;

            while (arrayPosition < intArray.Length)
            {
                Write("Enter an integer, or Q to quit: ");
                input = ReadLine().ToUpper();

                if (Convert.ToChar(input) == QUIT)
                { 
                    arrayPosition = intArray.Length;
                }
                else if (!int.TryParse(input, out numberInput))
                    WriteLine("It was not an integer.\n");
                else
                { 
                    intArray[arrayPosition] = numberInput;
                    arrayPosition++;
                }
            }
            WriteLine("Entering integers has ended.\n");
        }

        private static void NumberPicker(ref int[] intArray, out int highest, out int lowest, out int sum, out int average)
        {
            Sort(intArray);
            highest = intArray[intArray.Length-1];

            lowest = intArray[0];
            sum = 0;
            average = 0;

            for (int i = 0; i < intArray.Length; i++)
                sum += intArray[i];
            for (int i = 0; i < intArray.Length; i++)
                average = sum / intArray.Length;
        }

        private static void Border(string word)
        {
            string result;

            result = "**********" + word + "**********";

            WriteLine(result);
        }
    }
}
