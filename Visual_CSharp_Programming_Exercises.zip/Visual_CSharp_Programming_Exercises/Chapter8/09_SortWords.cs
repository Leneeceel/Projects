﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class SortWords
    {
        static void Main(string[] args)
        {
            WordSort("one");
            WriteLine("\n\n\n\n");
            WordSort("one", "two");
            WriteLine("\n\n\n\n");
            WordSort("one", "two", "three", "four", "five");
            WriteLine("\n\n\n\n");
            WordSort("one", "two", "three", "four", "five",
                     "six", "seven", "eight", "nine", "ten");

        }

        static void WordSort(params string[] wordArray)
        {

            for (int i = 0; i < wordArray.Length; i++)
            {
                char[] charArray = new char[wordArray[i].Length];

                for (int ii = 0; ii < wordArray[i].Length; ii++)
                    charArray[ii] = Convert.ToChar(wordArray[i].Substring(ii,1));
                Sort(charArray);

                if (wordArray[i] != "")
                { 
                Write("Alphabetical order: ");
                foreach (char item in charArray)
                {
                    Write("{0}", item);
                }
                WriteLine("\n\n");
                }
            }

        }
    }
}