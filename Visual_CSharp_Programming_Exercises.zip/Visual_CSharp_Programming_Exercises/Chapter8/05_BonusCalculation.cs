﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class BonusCalculation
    {
        static void Main(string[] args)
        {
            double salary;
            double bonus;

            //WriteLine("Double");
            //Write("Enter your salary: ");
            //salary = Convert.ToDouble(ReadLine());
            //Write("Enter your bonus: ");
            //bonus = Convert.ToDouble(ReadLine());
            //GetSalary(salary, bonus);
            //WriteLine();
            //WriteLine();

            //WriteLine("Integer");
            //Write("Enter your salary: ");
            //salary = Convert.ToDouble(ReadLine());
            //Write("Enter your bonus: ");
            //bonus = Convert.ToDouble(ReadLine());
            //GetSalary(salary, Convert.ToInt32(bonus));

            WriteLine("When bonus is an integer");
            GetSalary(500, 25);
            WriteLine("\n\n");
            WriteLine("When bonus is a double");
            GetSalary(500, 0.05);
        }

        static void GetSalary(double salary, int bonus)
        {
            double total;

            total = salary + bonus;

            WriteLine("Your salary: {0:C}", salary);
            WriteLine("Your bonus : {0:C}", bonus);
            WriteLine("Total      : {0:C}", total);
        }

        static void GetSalary(double salary, double bonus)
        {
            double total;

            bonus = salary * bonus;

            total = salary + bonus;

            WriteLine("Your salary: {0:C}", salary);
            WriteLine("Your bonus : {0:C}", bonus);
            WriteLine("Total      : {0:C}", total);
        }

        static void TestMethod(double d)
        {
            WriteLine("Double test method");
        }

        static void TestMethod(int i)
        {
            WriteLine("Int test method");
        }
    }
}
