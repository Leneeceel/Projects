﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter7
{
    class WarCardGame
    {
        static void Main(string[] args)
        {
            int[] deck = new int[52];
            string[] deckString = new string[52];
            string computerCard = "";
            string playerCard = "";
            int computerScore = 0;
            int playerScore = 0;
            int deal = 1;
            

            int computerComparer = 0,
                playerComparer = 0;


            while (deal <= deck.Length/2)
            {
                FillDect(ref deck);
                AssignCard(ref deck, ref deckString);

                WriteLine("Deal #{0}", deal);
                deal++;
                SelectCard(ref deckString, ref playerCard, ref computerCard);

                WriteLine("   Computer has {0}", computerCard);
                WriteLine("   Player has {0}", playerCard);
                for (int i = 0; i < deckString.Length; i++)
                {
                    if (deckString[i] == computerCard)
                        computerComparer = deck[i] % 100;

                    if (deckString[i] == playerCard)
                        playerComparer = deck[i] % 100;
                }

                if (computerComparer > playerComparer)
                    computerScore += 2;
                else if (computerComparer < playerComparer)
                    playerScore += 2;

                WriteLine("Computer score is {0}", computerScore);
                WriteLine("Player score is {0}", playerScore);
                ReadLine();

            }            
        }

        static void FillDect(ref int[] deck)
        {
            int shape = 100,
                counter = 0;

            while (counter < deck.Length)
            {
                for (int i = 1; i < 14; i++)
                {
                    deck[counter] = shape + i;
                    counter++;
                }
                shape += 100;
            }


        }

        static void SelectCard(ref string[] deckString, ref string playerCard, ref string computerCard)
        {
            int[] used = new int[52];
            int randomNum;
            int randomNum2;
            int counter = 0;
            Random randomGenerator = new Random();


            randomNum = randomGenerator.Next(0, 52);
            randomNum2 = randomGenerator.Next(0, 52);

            used[counter] = randomNum;
            counter++;
            used[counter] = randomNum2;
            counter++;
            Sort(used);

            if (BinarySearch(used, randomNum) < 0 && 
                BinarySearch(used, randomNum2) < 0)
            {
                playerCard = deckString[randomNum];
                computerCard = deckString[randomNum2];
            }
            else if ()
            {

            }




        }

        static void AssignCard(ref int[] deck, ref string[] deckString)
        {
            for (int i = 0; i < deckString.Length; i++)
            {
                deckString[i] = Convert.ToString(deck[i] % 100);
                if (deck[i] % 100 == 11)
                    deckString[i] = "Jack";
                if (deck[i] % 100 == 12)
                    deckString[i] = "Queen";
                if (deck[i] % 100 == 13)
                    deckString[i] = "King";

                if (deck[i] >= 100 && deck[i] < 200)
                    deckString[i] += " of spades";
                else if (deck[i] >= 200 && deck[i] < 300)
                    deckString[i] += " of clubs";
                else if (deck[i] >= 300 && deck[i] < 400)
                    deckString[i] += " of hearts";
                else if (deck[i] >= 400 && deck[i] < 500)
                    deckString[i] += " of diamonds";
            }
        }
    }
}
