﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter7
{
    class WarCardGame_v2_1
    {
        static void Main(string[] args)
        {
            int[] deck = new int[52];
            string[] deckString = new string[52];

            string[] player = new string[26];
            string[] computer = new string[26];
            string playerCard,
                computerCard;
            int computerScore = 0,
                playerScore = 0;
            int computerComparer = 0,
                playerComparer = 0;
            int deal = 1;

            FillDect(ref deck);
            AssignCard(ref deck, ref deckString);

            DealCards(ref deckString, ref player, ref computer);


            for (int i = 0; i < player.Length; i++)
            { 
                WriteLine("Deal #{0}", deal);
                deal++;

                computerCard = SelectCard(ref computer);
                playerCard = SelectCard(ref player);
                WriteLine("   Computer has {0}", computerCard);
                WriteLine("   Player has {0}", playerCard);

                for (int ii = 0; ii < deckString.Length; ii++)
                {
                    if (deckString[ii] == computerCard)
                        computerComparer = deck[ii] % 100;
                    else if (deckString[ii] == playerCard)
                        playerComparer = deck[ii] % 100;
                }

                if (computerComparer > playerComparer)
                    computerScore += 2;
                else if (computerComparer < playerComparer)
                    playerScore += 2;
                else
                {
                    computerScore++;
                    playerScore++;
                }


                WriteLine("Computer score is {0}", computerScore);
                WriteLine("Player score is {0}", playerScore);
                ReadLine();
            }
        }

        static void FillDect(ref int[] deck)
        {
            int shape = 100,
                counter = 0;

            while (counter < deck.Length)
            {
                for (int i = 1; i < 14; i++)
                {
                    deck[counter] = shape + i;
                    counter++;
                }
                shape += 100;
            }
        }

        static string SelectCard(ref string[] playerDeck)
        {
            string[] used = new string[52];
            int counter = 0;
            int rNum = 0;
            Random randomGenerator = new Random();
            rNum = randomGenerator.Next(0, playerDeck.Length);
            

            while (ExistingNum(ref playerDeck, ref used, rNum))
                rNum = randomGenerator.Next(0, playerDeck.Length);

            used[counter] = playerDeck[rNum];
            counter++;

            return playerDeck[rNum];
        }

        static void DealCards(ref string[] deck, ref string[] player, ref string[] computer)
        {
            int rNum,
                rNum2;

            Random rNumG = new Random();

            for (int i = 0; i < deck.Length / 2; i++)
            {
                rNum = rNumG.Next(0, 51);
                rNum2 = rNumG.Next(0, 51);

                while (ExistingNum(ref deck, ref player, rNum) || ExistingNum(ref deck, ref computer, rNum) ||
                       ExistingNum(ref deck, ref computer, rNum2) || ExistingNum(ref deck, ref player, rNum2))
                { 
                    rNum = rNumG.Next(0, 51);
                    rNum2 = rNumG.Next(0, 51);
                }

                player[0] = deck[rNum];
                computer[0] = deck[rNum2];

            }
        }

        static bool ExistingNum(ref string[] deck, ref string[] playerDeck, int num)
        {
            bool isNumExisting = false;

            Sort(playerDeck);

            if (BinarySearch(playerDeck, deck[num]) > 0)
            {
                isNumExisting = true;
            }

            return isNumExisting;
        }

        static void AssignCard(ref int[] deck, ref string[] deckString)
        {
            for (int i = 0; i < deckString.Length; i++)
            {
                deckString[i] = Convert.ToString(deck[i] % 100);
                if (deck[i] % 100 == 11)
                    deckString[i] = "Jack";
                if (deck[i] % 100 == 12)
                    deckString[i] = "Queen";
                if (deck[i] % 100 == 13)
                    deckString[i] = "King";

                if (deck[i] >= 100 && deck[i] < 200)
                    deckString[i] += " of spades";
                else if (deck[i] >= 200 && deck[i] < 300)
                    deckString[i] += " of clubs";
                else if (deck[i] >= 300 && deck[i] < 400)
                    deckString[i] += " of hearts";
                else if (deck[i] >= 400 && deck[i] < 500)
                    deckString[i] += " of diamonds";
            }
        }

    }
}
