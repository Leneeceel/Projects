﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class Reverse3
    {
        static void Main(string[] args)
        {
            int firstInt,
                middleInt,
                lastInt;

            firstInt = 1;
            middleInt = 2;
            lastInt = 3;

            WriteLine("{0}\n{1}\n{2}", firstInt, middleInt, lastInt);
            WriteLine("-------------");
            IntMethod(ref firstInt, ref middleInt, ref lastInt);
        }

        static int IntMethod(ref int firstInt, ref int middleInt, ref int lastInt)
        {
            WriteLine("{0}\n{1}\n{2}", lastInt, middleInt, firstInt);
            return firstInt;
        }
    }
}
