﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter7
{
    class WarCardGame_v2_1
    {
        static void Main(string[] args)
        {
            int[] deck = new int[52];
            int[] player = new int[26];
            int[] computer = new int[26];
            //int player;
            //int computer;
            int deal = 1;

            FillDect(ref deck);
            DealCards(ref deck, ref player, ref computer);

            WriteLine("Deal #{0}", deal);
            deal++;
            //SelectCard(ref player);
            //SelectCard(ref computer);


            WriteLine("   Computer has {0}", SelectCard(ref computer));
            WriteLine("   Player has {0}", SelectCard(ref player));
        }

        static void FillDect(ref int[] deck)
        {
            int shape = 100,
                counter = 0;

            while (counter < deck.Length)
            {
                for (int i = 1; i < 14; i++)
                {
                    deck[counter] = shape + i;
                    counter++;
                }
                shape += 100;
            }
        }

        static int SelectCard(ref int[] playerDeck)
        {
            int[] used = new int[52];
            int counter = 0;
            int rNum = 0;
            Random randomGenerator = new Random();
            rNum = randomGenerator.Next(0, playerDeck.Length);
            

            while (ExistingNum(ref playerDeck, ref used, rNum))
                rNum = randomGenerator.Next(0, playerDeck.Length);

            used[counter] = playerDeck[rNum];
            counter++;

            return playerDeck[rNum];
        }

        static void DealCards(ref int[] deck, ref int[] player, ref int[] computer)
        {
            int rNum,
                rNum2;

            Random rNumG = new Random();

            for (int i = 0; i < deck.Length / 2; i++)
            {
                rNum = rNumG.Next(0, 51);
                rNum2 = rNumG.Next(0, 51);

                while (ExistingNum(ref deck, ref player, rNum) || ExistingNum(ref deck, ref computer, rNum) ||
                       ExistingNum(ref deck, ref computer, rNum2) || ExistingNum(ref deck, ref player, rNum2))
                { 
                    rNum = rNumG.Next(0, 51);
                    rNum2 = rNumG.Next(0, 51);
                }

                player[0] = deck[rNum];
                computer[0] = deck[rNum2];

            }
        }

        static bool ExistingNum(ref int[] deck, ref int[] playerDeck, int num)
        {
            bool isNumExisting = false;

            Sort(playerDeck);

            if (BinarySearch(playerDeck, deck[num]) > 0)
            {
                isNumExisting = true;
            }

            return isNumExisting;
        }

        static void AssignCard(ref int[] deck, ref string[] deckString)
        {
            for (int i = 0; i < deckString.Length; i++)
            {
                deckString[i] = Convert.ToString(deck[i] % 100);
                if (deck[i] % 100 == 11)
                    deckString[i] = "Jack";
                if (deck[i] % 100 == 12)
                    deckString[i] = "Queen";
                if (deck[i] % 100 == 13)
                    deckString[i] = "King";

                if (deck[i] >= 100 && deck[i] < 200)
                    deckString[i] += " of spades";
                else if (deck[i] >= 200 && deck[i] < 300)
                    deckString[i] += " of clubs";
                else if (deck[i] >= 300 && deck[i] < 400)
                    deckString[i] += " of hearts";
                else if (deck[i] >= 400 && deck[i] < 500)
                    deckString[i] += " of diamonds";
            }
        }

    }
}
