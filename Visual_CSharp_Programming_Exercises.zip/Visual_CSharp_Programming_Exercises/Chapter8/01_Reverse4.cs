﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class Reverse4
    {
        static void Main(string[] args)
        {
            int firstInt,
                middleInt,
                lastInt,
                oneMoreInt;

            firstInt = 1;
            middleInt = 2;
            lastInt = 3;
            oneMoreInt = 4;

            WriteLine("{0}\n{1}\n{2}\n{3}", firstInt, middleInt, lastInt, oneMoreInt);
            WriteLine("-------------");
            IntMethod(ref firstInt, ref middleInt, ref lastInt, ref oneMoreInt);
        }

        static int IntMethod(ref int firstInt, ref int middleInt, ref int lastInt, ref int oneMoreInt)
        {
            WriteLine("{0}\n{1}\n{2}\n{3}", oneMoreInt, lastInt, middleInt, firstInt);
            return firstInt;
        }
    }
}
