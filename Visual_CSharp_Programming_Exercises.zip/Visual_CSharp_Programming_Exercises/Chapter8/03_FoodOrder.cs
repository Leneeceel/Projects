﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class FoodOrder
    {
        static void Main(string[] args)
        {
            string[] description = { "Enchilada", "Burrito", "Taco", "Tostada" };
            int[] itemNo = { 20, 23, 25, 31 };
            double[] price = { 2.95, 1.95, 2.25, 3.10 };
            bool isItemFound = false;
            string userOrder;

            Stars("The Cactus Cantina");
            WriteLine();
            WriteLine("  {0,-10} {1,-10} {2,-5}\n", "Item No.", "Name", "Price");

            for (int i = 0; i < description.Length; i++)
                WriteLine("  {0,-10} {1,-10} {2,-5:C2}", itemNo[i], description[i], price[i]);
            WriteLine();

            Write("Choose a menu: ");
            userOrder = ReadLine();
            userOrder = CaseModifier(userOrder);
            int.TryParse(userOrder, out int result);
            WriteLine();

            for (int i = 0; i < description.Length; i++)
            {
                if (userOrder == description[i] || result == itemNo[i])
                { 
                    isItemFound = true;
                    i = description.Length;
                }
                else
                    isItemFound = false;
            }

            if (!isItemFound)
                WriteLine("The item was not found.");
            else if (int.TryParse(userOrder, out int userOrderNo))
                GetDetails(ref description, ref itemNo, ref price, userOrderNo);
            else
                GetDetails(ref description, ref itemNo, ref price, userOrder);

        }

        static void GetDetails( ref string[] desc, ref int[] itemNo, ref double[] price, string userOrder)
        {
            int itemNoDisplayed = 0;
            double priceDisplayed = 0;

            for (int i = 0; i < desc.Length; i++)
            {
                if (userOrder == desc[i])
                {
                    itemNoDisplayed = itemNo[i];
                    priceDisplayed = price[i];
                    i = desc.Length;
                }
            }

            WriteLine("The information for {0}", userOrder);
            WriteLine("{0,-10} {1,-5}", "Item No.", "Price");
            WriteLine("{0,-10} {1,-5:C2}", itemNoDisplayed, priceDisplayed);
        }
        static void GetDetails(ref string[] desc, ref int[] itemNo, ref double[] price, int userOrderNo)
        {
            string userOrderDisplayed = "";
            double priceDisplayed = 0;

            for (int i = 0; i < itemNo.Length; i++)
            {
                if (userOrderNo == itemNo[i])
                {
                    userOrderDisplayed = desc[i];
                    priceDisplayed = price[i];
                }
            }

            WriteLine("The information for menu {0}", userOrderNo);
            WriteLine("{0,-13} {1,-5}", "Name", "Price");
            WriteLine("{0,-13} {1,-5:C2}", userOrderDisplayed, priceDisplayed);
        }

        static string CaseModifier(string word)
        {
            word.Substring(0,1).ToUpper();
            word.Substring(1, word.Length-1).ToLower();

            word = word.Substring(0, 1).ToUpper() + word.Substring(1, word.Length - 1).ToLower();

            return word;
        }

        static void Stars(string word)
        {
            WriteLine("**********" + word + "**********");
        }
    }
}