﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;
namespace Chapter8
{
    class Desks
    {
        static void Main(string[] args)
        {
            int numOfDrawers = 0;
            char woodType = ' ';
            double total = 0;

            NumberOfDrawers(ref numOfDrawers);
            WoodType(ref woodType);

            TotalCalc(ref numOfDrawers, ref woodType, out total);

            GetInfo(numOfDrawers, woodType, total);
            //GetInfo(numOfDrawers, woodType, TotalCalc(numOfDrawers, woodType));
        }

        static void NumberOfDrawers(ref int numOfDrawers)
        {
            Write("Enter number of drawers: ");
            numOfDrawers = Convert.ToInt32(ReadLine());
        }

        static void WoodType(ref char woodType)
        {
            Write("Enter a wood type (m for mahogany, o for oak, or p for pine): ");
            woodType = Convert.ToChar(ReadLine().ToLower());
        }

        static void TotalCalc(ref int numOfDrawers, ref char woodType, out double total)
        {
            double priceEach;
            const int SURCHARGE = 30;
            
            switch (woodType)
            {
                case 'm':
                    priceEach = 180;
                    break;
                case 'o':
                    priceEach = 140;
                    break;
                case 'p':
                    priceEach = 100;
                    break;
                default:
                    priceEach = 0;
                    break;
            }

            total = (numOfDrawers * priceEach) + (numOfDrawers * SURCHARGE);
        }

        static void GetInfo(int numOfDrawers, char woodType, double total)
        {
            string woodTypeDisplayed;

            switch (woodType)
            {
                case 'm':
                    woodTypeDisplayed = "mahogany";
                    break;
                case 'o':
                    woodTypeDisplayed = "oak";
                    break;
                case 'p':
                    woodTypeDisplayed = "pine";
                    break;
                default:
                    woodTypeDisplayed = "";
                    break;
            }
            WriteLine("{0} {1} drawer{2}", numOfDrawers, woodTypeDisplayed, numOfDrawers > 1 ? "s" : "");
            WriteLine("Total: {0:C}", total);
        }
    }
}
