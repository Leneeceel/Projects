﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Array;

namespace Chapter8
{
    class Averages
    {
        static void Main(string[] args)
        {
            int[] intArray = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            Average(1);
            Average(1, 2);
            Average(1, 2, 3);
            Average(intArray);

        }

        static void Average(int num1)
        {
            WriteLine("The overloaded first method");
            WriteLine("The num: {0}", num1);
        }

        static void Average(int num1, int num2)
        {
            WriteLine("The overloaded second method");
            WriteLine("The average: {0}", ( num1 + num2 ) / 2);
        }
        static void Average(int num1, int num2, int num3)
        {
            WriteLine("The overloaded third method");
            WriteLine("The average: {0}", (num1 + num2 + num3) / 3);
        }
        static void Average(int[] intArray)
        {
            int average;
            int sum = 0;
            foreach (int num in intArray)
                sum += num;

            average = sum / intArray.Length;

            WriteLine("The overloaded forth method");
            WriteLine("The average: {0}", average);
        }
    }
}
